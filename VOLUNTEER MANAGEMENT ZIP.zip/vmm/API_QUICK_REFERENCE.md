# VolunteerHub API - Quick Reference Guide

## Base URL
```
http://localhost:8080
```

## Standard Response Format
```json
{
  "status": "SUCCESS",
  "message": "Operation successful",
  "data": {},
  "timestamp": 1707858000000
}
```

## Authentication

### Register User
```bash
POST /api/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "SecurePass123",
  "confirmPassword": "SecurePass123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "VOLUNTEER"  // or ORGANIZER
}
```

### Login
```bash
POST /api/auth/login
Content-Type: application/json

{
  "username": "johndoe",
  "password": "SecurePass123"
}
```

## Using JWT Token
```bash
Authorization: Bearer <your_jwt_token_here>
```

## User Endpoints

### Get All Users (Paginated)
```bash
GET /api/users?page=0&size=10
Authorization: Bearer <token>
```

### Get User by ID
```bash
GET /api/users/{userId}
Authorization: Bearer <token>
```

### Get User by Username
```bash
GET /api/users/username/{username}
Authorization: Bearer <token>
```

### Create User (Organizer only)
```bash
POST /api/users
Authorization: Bearer <token>
Content-Type: application/json

{
  "username": "jane_organizer",
  "email": "jane@example.com",
  "password": "SecurePass123",
  "firstName": "Jane",
  "lastName": "Smith",
  "role": "ORGANIZER"
}
```

### Update User (Organizer only)
```bash
PUT /api/users/{userId}
Authorization: Bearer <token>
Content-Type: application/json

{
  "username": "jane_organizer",
  "email": "jane@example.com",
  "firstName": "Jane",
  "lastName": "Smith"
}
```

### Delete User (Organizer only)
```bash
DELETE /api/users/{userId}
Authorization: Bearer <token>
```

## Event Endpoints

### Get All Events (Paginated)
```bash
GET /api/events?page=0&size=10&sort=id,desc
Authorization: Bearer <token>
```

### Get Event by ID
```bash
GET /api/events/{eventId}
Authorization: Bearer <token>
```

### Get Events by Organizer
```bash
GET /api/events/organizer/{organizerId}?page=0&size=10
Authorization: Bearer <token>
```

### Get Events by Status
```bash
GET /api/events/status/SCHEDULED?page=0&size=10
Authorization: Bearer <token>
```

### Get Events with Available Spots
```bash
GET /api/events/available-spots?page=0&size=10
Authorization: Bearer <token>
```

### Create Event (Organizer only)
```bash
POST /api/events
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Beach Cleanup",
  "description": "Help clean up the beach",
  "location": "Santa Monica Beach",
  "eventDate": "2026-03-15T10:00:00",
  "startTime": "2026-03-15T10:00:00",
  "endTime": "2026-03-15T14:00:00",
  "maxVolunteers": 50
}
```

### Update Event (Organizer only)
```bash
PUT /api/events/{eventId}
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Updated Title",
  "description": "Updated description",
  "location": "New Location",
  "eventDate": "2026-03-20T10:00:00",
  "startTime": "2026-03-20T10:00:00",
  "endTime": "2026-03-20T14:00:00",
  "maxVolunteers": 75,
  "status": "SCHEDULED"
}
```

### Delete Event (Organizer only)
```bash
DELETE /api/events/{eventId}
Authorization: Bearer <token>
```

### Update Event Status (Organizer only)
```bash
PATCH /api/events/{eventId}/status?status=IN_PROGRESS
Authorization: Bearer <token>
```

## Participation Endpoints

### Join Event
```bash
POST /api/events/{eventId}/join
Authorization: Bearer <token>
```

### Cancel Participation
```bash
DELETE /api/events/{eventId}/cancel
Authorization: Bearer <token>
```

### Check Participation
```bash
GET /api/events/{eventId}/check-participation
Authorization: Bearer <token>
```

### Get Event Participants (Organizer only)
```bash
GET /api/events/{eventId}/participants?page=0&size=10
Authorization: Bearer <token>
```

## Feedback Endpoints

### Submit Feedback
```bash
POST /api/feedback
Authorization: Bearer <token>
Content-Type: application/json

{
  "eventId": 1,
  "rating": 5,
  "comment": "Great event! Very organized."
}
```

### Get Event Feedback (Organizer only)
```bash
GET /api/events/{eventId}/feedback?page=0&size=10
Authorization: Bearer <token>
```

### Get Average Rating for Event
```bash
GET /api/events/{eventId}/feedback/average-rating
```

### Get My Feedback
```bash
GET /api/feedback/my-feedback?page=0&size=10
Authorization: Bearer <token>
```

### Get Volunteer's Feedback
```bash
GET /api/feedback/volunteer/{volunteerId}?page=0&size=10
```

### Get Volunteer's Average Rating
```bash
GET /api/feedback/volunteer/{volunteerId}/average-rating
```

### Delete Feedback
```bash
DELETE /api/feedback/{feedbackId}
Authorization: Bearer <token>
```

## Notification Endpoints

### Get All Notifications
```bash
GET /api/notifications?page=0&size=10
Authorization: Bearer <token>
```

### Get Unread Notifications
```bash
GET /api/notifications/unread?page=0&size=10
Authorization: Bearer <token>
```

### Get Unread Count
```bash
GET /api/notifications/unread/count
Authorization: Bearer <token>
```

### Mark Notification as Read
```bash
PUT /api/notifications/{notificationId}/read
Authorization: Bearer <token>
```

### Mark All as Read
```bash
PUT /api/notifications/read-all
Authorization: Bearer <token>
```

### Delete Notification
```bash
DELETE /api/notifications/{notificationId}
Authorization: Bearer <token>
```

### Delete All Notifications
```bash
DELETE /api/notifications
Authorization: Bearer <token>
```

## Status Codes & Meanings

| Code | Meaning | Status Type |
|------|---------|------------|
| 200 | OK | SUCCESS |
| 201 | Created | SUCCESS |
| 204 | No Content | SUCCESS |
| 400 | Bad Request | ERROR / VALIDATION_ERROR |
| 401 | Unauthorized | UNAUTHORIZED |
| 403 | Forbidden | FORBIDDEN |
| 404 | Not Found | NOT_FOUND |
| 409 | Conflict | CONFLICT |
| 500 | Internal Server Error | ERROR |

## Common Request Headers

```
Content-Type: application/json
Authorization: Bearer <jwt_token>
```

## Event Statuses
- `SCHEDULED` - Event is scheduled
- `IN_PROGRESS` - Event is currently happening
- `COMPLETED` - Event is completed
- `CANCELLED` - Event is cancelled

## Participation Statuses
- `JOINED` - Volunteer joined
- `CANCELLED` - Volunteer cancelled
- `COMPLETED` - Event completed
- `NO_SHOW` - Volunteer didn't show

## Notification Types
- `VOLUNTEER_JOINED` - Volunteer joined event
- `VOLUNTEER_CANCELLED` - Volunteer cancelled event
- `EVENT_CREATED` - Event was created
- `EVENT_UPDATED` - Event was updated
- `EVENT_CANCELLED` - Event was cancelled
- `EVENT_COMPLETED` - Event is completed
- `NEW_FEEDBACK` - New feedback received

## Validation Rules

### Username
- Required, not blank
- Length: 5-50 characters

### Email
- Required, not blank
- Valid email format

### Password
- Required, not blank
- Length: 8+ characters
- Must match confirmPassword on registration

### First Name / Last Name
- Required, not blank

### Event Title
- Required, not blank

### Event Location
- Required, not blank

### Event Date/Time
- Required, not null

### Rating (Feedback)
- Required
- Range: 1-5

### Max Volunteers
- Optional
- Must be zero or positive

## Example Full Workflow

### 1. Register as Volunteer
```bash
POST /api/auth/register
{"username": "vol1", "email": "vol@test.com", "password": "Pass123456", 
 "firstName": "Volunteer", "lastName": "One", "role": "VOLUNTEER"}
```
Response: Get JWT token

### 2. Register as Organizer
```bash
POST /api/auth/register
{"username": "org1", "email": "org@test.com", "password": "Pass123456",
 "firstName": "Organizer", "lastName": "One", "role": "ORGANIZER"}
```
Response: Get JWT token

### 3. Create Event (Organizer)
```bash
POST /api/events
Authorization: Bearer <organizer_token>
{"title": "Beach Cleanup", "location": "Santa Monica", ...}
```
Response: Event ID = 1

### 4. Join Event (Volunteer)
```bash
POST /api/events/1/join
Authorization: Bearer <volunteer_token>
```
Response: Participation created, notification sent to organizer

### 5. Submit Feedback (Volunteer)
```bash
POST /api/feedback
Authorization: Bearer <volunteer_token>
{"eventId": 1, "rating": 5, "comment": "Great!"}
```
Response: Feedback created

### 6. View Feedback (Organizer)
```bash
GET /api/events/1/feedback
Authorization: Bearer <organizer_token>
```
Response: All feedback for event

### 7. Cancel Participation (Volunteer)
```bash
DELETE /api/events/1/cancel
Authorization: Bearer <volunteer_token>
```
Response: Participation cancelled, notification sent

## Pagination Query Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| page | 0 | Page number (0-indexed) |
| size | 10 | Items per page |
| sort | id,desc | Sort criteria (field,direction) |

Example:
```
GET /api/events?page=2&size=20&sort=eventDate,asc
```

## Error Response Examples

### Validation Error (400)
```json
{
  "status": "VALIDATION_ERROR",
  "message": "Validation failed",
  "data": {
    "email": "Email should be valid",
    "password": "Password must be at least 8 characters"
  },
  "timestamp": 1707858000000
}
```

### Unauthorized (401)
```json
{
  "status": "UNAUTHORIZED",
  "message": "Invalid username or password",
  "data": null,
  "timestamp": 1707858000000
}
```

### Forbidden (403)
```json
{
  "status": "FORBIDDEN",
  "message": "You are not authorized to update this event.",
  "data": null,
  "timestamp": 1707858000000
}
```

### Not Found (404)
```json
{
  "status": "NOT_FOUND",
  "message": "Event not found with ID: 999",
  "data": null,
  "timestamp": 1707858000000
}
```

### Conflict (409)
```json
{
  "status": "CONFLICT",
  "message": "Volunteer has already joined this event.",
  "data": null,
  "timestamp": 1707858000000
}
```

## Tips & Tricks

1. **Always include Authorization header** for protected endpoints
2. **Check status field** in response to determine success/failure
3. **Use pagination** for large datasets (page, size)
4. **Handle timestamps** - they're in Unix milliseconds
5. **Validate input** before sending - reduces 400 errors
6. **Check HTTP status codes** - they match response status
7. **Store JWT tokens securely** - typically in secure HTTP-only cookies
8. **Implement token refresh** - JWT tokens may expire

## Testing with cURL

### Set token as variable
```bash
TOKEN="your_jwt_token_here"
```

### Test with Authorization
```bash
curl -X GET http://localhost:8080/api/events \
  -H "Authorization: Bearer $TOKEN"
```

### Test POST with data
```bash
curl -X POST http://localhost:8080/api/events \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d @event.json
```

### Pretty print JSON response
```bash
curl ... | jq
```

## Production Considerations

1. Use HTTPS instead of HTTP
2. Set JWT expiration times appropriately
3. Implement rate limiting on auth endpoints
4. Log all errors and exceptions
5. Monitor notification queue
6. Backup database regularly
7. Use environment variables for sensitive config
8. Enable CORS appropriately
9. Implement API versioning (/api/v1/...)
10. Add request/response logging

---

**Last Updated:** February 14, 2026  
**API Version:** 1.0  
**Framework:** Spring Boot 3.2.0
