# VolunteerHub - Database Schema

## Auto-Generated Schema (Spring Data JPA)

With `spring.jpa.hibernate.ddl-auto: update` in `application.yml`, Hibernate will automatically create/update the database schema.

---

## SQL Schema

### Users Table

```sql
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6),
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255),
  `last_name` varchar(255),
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

---

## Table Details

### `users` Table

| Column | Type | Nullable | Key | Default | Description |
|--------|------|----------|-----|---------|-------------|
| `id` | bigint | NO | PRIMARY | auto_increment | User ID (Primary Key) |
| `username` | varchar(255) | NO | UNIQUE | - | Username (Unique) |
| `email` | varchar(255) | NO | UNIQUE | - | Email address (Unique) |
| `password` | varchar(255) | NO | - | - | BCrypt encrypted password |
| `first_name` | varchar(255) | YES | - | NULL | First name |
| `last_name` | varchar(255) | YES | - | NULL | Last name |
| `role` | varchar(255) | NO | - | - | User role (ROLE_VOLUNTEER or ROLE_ORGANIZER) |
| `active` | bit(1) | NO | - | 1 | Account active status |
| `created_at` | datetime(6) | NO | - | NOW() | Creation timestamp |
| `updated_at` | datetime(6) | YES | - | NOW() | Last update timestamp |

---

## Sample Data

### Insert Users

```sql
-- Insert volunteer user
INSERT INTO users (
  username, email, password, first_name, last_name, role, active, created_at, updated_at
) VALUES (
  'alice_volunteer',
  'alice@volunteerhub.com',
  '$2a$10$...',  -- BCrypt hashed password
  'Alice',
  'Smith',
  'ROLE_VOLUNTEER',
  true,
  NOW(),
  NOW()
);

-- Insert organizer user
INSERT INTO users (
  username, email, password, first_name, last_name, role, active, created_at, updated_at
) VALUES (
  'bob_organizer',
  'bob@volunteerhub.com',
  '$2a$10$...',  -- BCrypt hashed password
  'Bob',
  'Johnson',
  'ROLE_ORGANIZER',
  true,
  NOW(),
  NOW()
);
```

---

## Indexes

### Existing Indexes
- `PRIMARY KEY (id)` - Primary key for user identification
- `UNIQUE KEY (username)` - Ensure username uniqueness
- `UNIQUE KEY (email)` - Ensure email uniqueness

### Recommended Indexes (Optional)

```sql
-- For faster queries by role
CREATE INDEX idx_users_role ON users(role);

-- For active user queries
CREATE INDEX idx_users_active ON users(active);

-- For timestamp-based queries
CREATE INDEX idx_users_created_at ON users(created_at);
CREATE INDEX idx_users_updated_at ON users(updated_at);
```

---

## Entity Relationships

Currently, the User entity has:
- **No associations** (simple single-table design)
- Direct role as enum stored in database
- Self-contained all user information

### Future Enhancements

If needed, you could add:

```
User (1) ──→ (*) Volunteer Activities
User (1) ──→ (*) Event Organization
User (1) ──→ (*) Audit Logs
User (1) ──→ (*) Notifications
```

---

## Query Examples

### Find User by Username
```sql
SELECT * FROM users WHERE username = 'alice_volunteer';
```

### Find All Volunteers
```sql
SELECT * FROM users WHERE role = 'ROLE_VOLUNTEER';
```

### Find All Organizers
```sql
SELECT * FROM users WHERE role = 'ROLE_ORGANIZER';
```

### Find Active Users
```sql
SELECT * FROM users WHERE active = 1;
```

### Find Users by Email Domain
```sql
SELECT * FROM users WHERE email LIKE '%@volunteerhub.com';
```

### Count Users by Role
```sql
SELECT role, COUNT(*) as count 
FROM users 
GROUP BY role;
```

### Find Recently Created Users
```sql
SELECT * FROM users 
ORDER BY created_at DESC 
LIMIT 10;
```

### Find Users Created in Last 7 Days
```sql
SELECT * FROM users 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
```

---

## Database Initialization Script

Create `src/main/resources/schema.sql` for manual initialization:

```sql
-- Drop existing table (optional, for fresh start)
-- DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `first_name` varchar(255) NULL,
  `last_name` varchar(255) NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL UNIQUE,
  PRIMARY KEY (`id`),
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_active` (`active`),
  INDEX `idx_users_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create indexes
CREATE UNIQUE INDEX idx_unique_username ON users(username);
CREATE UNIQUE INDEX idx_unique_email ON users(email);

-- Insert sample data
INSERT INTO users (username, email, password, first_name, last_name, role, active, created_at)
VALUES 
  ('volunteer1', 'volunteer1@example.com', '$2a$10$slYQmyNdGzin7olVN3p5Be7DlH.PKZbv5H8KnzzVgXXbVxzy7KLKA', 'John', 'Volunteer', 'ROLE_VOLUNTEER', true, NOW()),
  ('organizer1', 'organizer1@example.com', '$2a$10$slYQmyNdGzin7olVN3p5Be7DlH.PKZbv5H8KnzzVgXXbVxzy7KLKA', 'Jane', 'Organizer', 'ROLE_ORGANIZER', true, NOW());
```

To use this, add to `application.yml`:
```yaml
spring:
  jpa:
    hibernate:
      ddl-auto: validate  # Only validate schema
  sql:
    init:
      mode: always
      data-locations: classpath:schema.sql
```

---

## Database Connection Properties

```yaml
spring:
  datasource:
    # MySQL Connection
    url: jdbc:mysql://localhost:3306/volunteerhub?useSSL=False&allowPublicKeyRetrieval=True&serverTimezone=UTC
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
    
    # Connection Pool
    hikari:
      maximum-pool-size: 10
      minimum-idle: 5
      connection-timeout: 20000
      idle-timeout: 300000
      max-lifetime: 1200000

  jpa:
    # Hibernate Configuration
    hibernate:
      ddl-auto: update  # update, create, validate, create-drop
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQL8Dialect
        format_sql: true
        use_sql_comments: true
        jdbc:
          batch_size: 20
          fetch_size: 50
          batch_versioned_data: true
    show-sql: false
    open-in-view: false
```

---

## DDL Auto Options

| Option | Behavior |
|--------|----------|
| `create` | Creates schema on startup; doesn't drop on shutdown |
| `create-drop` | Creates schema; drops when SessionFactory closes |
| `update` | Updates schema to match entities; preserves data (RECOMMENDED) |
| `validate` | Validates schema; fails if mismatch; no changes |
| `none` | No automatic schema handling |

For **production**: Use `validate` or `none` with manual migrations

---

## Backup & Recovery

### Backup Database
```bash
mysqldump -u root -p volunteerhub > backup.sql
```

### Restore Database
```bash
mysql -u root -p volunteerhub < backup.sql
```

### Export Users to CSV
```sql
SELECT id, username, email, role, active, created_at 
INTO OUTFILE '/tmp/volunteerhub_users.csv'
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
FROM users;
```

---

## Performance Tuning

### Connection Pool Settings
```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: 20      # Adjust based on load
      minimum-idle: 5
      idle-timeout: 600000       # 10 minutes
      max-lifetime: 1800000      # 30 minutes
```

### Query Optimization
```yaml
spring:
  jpa:
    properties:
      hibernate:
        jdbc:
          batch_size: 25         # Batch inserts/updates
          fetch_size: 100        # Fetch results in batches
```

### Enable Query Logging (Development Only)
```yaml
logging:
  level:
    org.hibernate.SQL: DEBUG
    org.hibernate.type.descriptor.sql.BasicBinder: TRACE
```

---

## Data Constraints

### Username Constraints
- Unique across all users
- Case-sensitive in MySQL
- Max 255 characters

### Email Constraints
- Valid email format (enforced at application level)
- Unique across all users
- Max 255 characters

### Password Constraints
- BCrypt hashed (60 characters after hashing)
- Application enforces minimum 6 characters before hashing
- Never stored in plain text

### Role Constraints
- Only: ROLE_VOLUNTEER or ROLE_ORGANIZER
- Stored as VARCHAR (enum string)
- Cannot be null

---

## Future Extensions

### Add Audit Table
```sql
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Add Roles Table (for multi-role support)
```sql
CREATE TABLE `user_roles` (
  `user_id` bigint NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`, `role`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Add Activity Table
```sql
CREATE TABLE `activities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `organizer_id` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`organizer_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## Schema Validation

After application startup, verify schema:

```sql
-- Check table exists
SHOW TABLES LIKE 'users';

-- Describe table structure
DESC users;

-- Check indexes
SHOW INDEX FROM users;

-- Check table status
SHOW TABLE STATUS LIKE 'users';
```

---

## Troubleshooting

### Issue: Column Not Found
**Check**: Ensure entity fields match database columns
```java
// Entity field
private String firstname;  // ❌ Wrong: camelCase

// Should be
private String firstName;  // ✅ Correct: Spring converts to first_name
```

### Issue: Duplicate Key Error
**Check**: Ensure username/email uniqueness
```sql
SELECT COUNT(*) FROM users WHERE username = 'username';
```

### Issue: Password Too Long
**Check**: BCrypt hashes produce 60-character strings
```sql
ALTER TABLE users MODIFY COLUMN password varchar(255);
```

### Issue: DDL Auto Not Working
**Check**: Verify hibernate configuration
```yaml
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true         # Enable to see SQL
```

