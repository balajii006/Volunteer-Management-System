# VolunteerHub API Response Format Documentation

## Standard API Response Structure

All API responses follow a consistent format with four main fields:

```json
{
  "status": "SUCCESS|ERROR|VALIDATION_ERROR|UNAUTHORIZED|FORBIDDEN|NOT_FOUND|CONFLICT",
  "message": "Human-readable message describing the result",
  "data": {},
  "timestamp": 1707858000000
}
```

### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| status | String | Response status indicating the result type |
| message | String | Human-readable message describing the operation |
| data | Object | Response payload (can be null) |
| timestamp | Long | Unix timestamp in milliseconds when response was generated |

## Response Status Types

### SUCCESS (HTTP 200)
Operation completed successfully.

**Example:**
```json
{
  "status": "SUCCESS",
  "message": "User registered successfully",
  "data": {
    "id": 1,
    "username": "johndoe",
    "email": "john@example.com"
  },
  "timestamp": 1707858000000
}
```

### ERROR (HTTP 400/500)
Generic error occurred during processing.

**Example:**
```json
{
  "status": "ERROR",
  "message": "The parameter 'eventId' of value 'abc' could not be converted to type 'Long'",
  "data": null,
  "timestamp": 1707858000000
}
```

### VALIDATION_ERROR (HTTP 400)
Request validation failed. `data` field contains field-level validation errors.

**Example:**
```json
{
  "status": "VALIDATION_ERROR",
  "message": "Validation failed",
  "data": {
    "username": "Username is required",
    "email": "Email must be valid",
    "password": "Password must be at least 8 characters"
  },
  "timestamp": 1707858000000
}
```

### UNAUTHORIZED (HTTP 401)
Authentication failed or credentials are invalid.

**Example:**
```json
{
  "status": "UNAUTHORIZED",
  "message": "Invalid username or password",
  "data": null,
  "timestamp": 1707858000000
}
```

### FORBIDDEN (HTTP 403)
User is authenticated but not authorized to access the resource.

**Example:**
```json
{
  "status": "FORBIDDEN",
  "message": "You are not authorized to update this event. Only the organizer can modify events.",
  "data": null,
  "timestamp": 1707858000000
}
```

### NOT_FOUND (HTTP 404)
Requested resource does not exist.

**Example:**
```json
{
  "status": "NOT_FOUND",
  "message": "Event not found with ID: 999",
  "data": null,
  "timestamp": 1707858000000
}
```

### CONFLICT (HTTP 409)
Request conflicts with existing data (e.g., duplicate resource).

**Example:**
```json
{
  "status": "CONFLICT",
  "message": "Volunteer has already joined this event.",
  "data": null,
  "timestamp": 1707858000000
}
```

## Exception Handling Map

| Exception Class | HTTP Status | Status Type | Description |
|-----------------|------------|-------------|-------------|
| ResourceNotFoundException | 404 | NOT_FOUND | Resource doesn't exist |
| InvalidCredentialsException | 401 | UNAUTHORIZED | Login credentials invalid |
| UnauthorizedException | 403 | FORBIDDEN | User lacks permission |
| DuplicateResourceException | 409 | CONFLICT | Resource already exists |
| BadCredentialsException | 401 | UNAUTHORIZED | Spring Security auth failure |
| MethodArgumentNotValidException | 400 | VALIDATION_ERROR | Request validation failed |
| MethodArgumentTypeMismatchException | 400 | ERROR | Invalid parameter type |
| NoHandlerFoundException | 404 | NOT_FOUND | Endpoint not found |
| IllegalArgumentException | 400 | ERROR | Invalid argument |
| Generic Exception | 500 | ERROR | Unexpected server error |

## Common Use Cases

### 1. User Registration - Success
**Request:**
```bash
POST /api/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "SecurePassword123",
  "confirmPassword": "SecurePassword123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "VOLUNTEER"
}
```

**Response (201):**
```json
{
  "status": "SUCCESS",
  "message": "User registered successfully",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "type": "Bearer",
    "userId": 1,
    "username": "johndoe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "roles": ["ROLE_VOLUNTEER"],
    "active": true
  },
  "timestamp": 1707858000000
}
```

### 2. User Registration - Validation Error
**Request:**
```bash
POST /api/auth/register
Content-Type: application/json

{
  "username": "jo",
  "email": "invalid-email",
  "password": "short",
  "firstName": "",
  "role": "VOLUNTEER"
}
```

**Response (400):**
```json
{
  "status": "VALIDATION_ERROR",
  "message": "Validation failed",
  "data": {
    "email": "Email should be valid",
    "firstName": "First name is required",
    "password": "Password must be at least 8 characters",
    "username": "Username must be between 5 and 50 characters",
    "confirmPassword": "Passwords don't match"
  },
  "timestamp": 1707858000000
}
```

### 3. Event Creation - Success
**Request:**
```bash
POST /api/events
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "title": "Beach Cleanup",
  "description": "Help clean up the beach",
  "location": "Santa Monica Beach",
  "eventDate": "2026-03-15T10:00:00",
  "startTime": "2026-03-15T10:00:00",
  "endTime": "2026-03-15T14:00:00",
  "maxVolunteers": 50
}
```

**Response (201):**
```json
{
  "status": "SUCCESS",
  "message": "Event created successfully",
  "data": {
    "id": 1,
    "title": "Beach Cleanup",
    "description": "Help clean up the beach",
    "location": "Santa Monica Beach",
    "eventDate": "2026-03-15T10:00:00",
    "startTime": "2026-03-15T10:00:00",
    "endTime": "2026-03-15T14:00:00",
    "maxVolunteers": 50,
    "currentVolunteers": 0,
    "status": "SCHEDULED",
    "organizerId": 1,
    "organizerName": "Jane Smith",
    "createdAt": "2026-02-14T15:30:00",
    "updatedAt": "2026-02-14T15:30:00",
    "active": true
  },
  "timestamp": 1707858000000
}
```

### 4. Unauthorized Access - Organizer only endpoint
**Request:**
```bash
PUT /api/events/1
Authorization: Bearer <volunteer_jwt_token>
Content-Type: application/json

{
  "title": "Updated Title"
}
```

**Response (403):**
```json
{
  "status": "FORBIDDEN",
  "message": "You are not authorized to update this event. Only the organizer can modify events.",
  "data": null,
  "timestamp": 1707858000000
}
```

### 5. Duplicate Join - Already Joined
**Request:**
```bash
POST /api/events/1/join
Authorization: Bearer <volunteer_jwt_token>
```

**Response (409):**
```json
{
  "status": "CONFLICT",
  "message": "Volunteer has already joined this event.",
  "data": null,
  "timestamp": 1707858000000
}
```

### 6. Resource Not Found
**Request:**
```bash
GET /api/events/999
Authorization: Bearer <jwt_token>
```

**Response (404):**
```json
{
  "status": "NOT_FOUND",
  "message": "Event not found with ID: 999",
  "data": null,
  "timestamp": 1707858000000
}
```

### 7. Endpoint Not Found
**Request:**
```bash
GET /api/invalid/endpoint
Authorization: Bearer <jwt_token>
```

**Response (404):**
```json
{
  "status": "NOT_FOUND",
  "message": "Resource not found: GET http://localhost:8080/api/invalid/endpoint",
  "data": null,
  "timestamp": 1707858000000
}
```

### 8. Invalid Credentials
**Request:**
```bash
POST /api/auth/login
Content-Type: application/json

{
  "username": "johndoe",
  "password": "wrongpassword"
}
```

**Response (401):**
```json
{
  "status": "UNAUTHORIZED",
  "message": "Invalid username or password",
  "data": null,
  "timestamp": 1707858000000
}
```

## Error Handling Best Practices

### Client-Side Implementation

```javascript
// JavaScript/Fetch
fetch('/api/events', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(eventData)
})
.then(res => res.json())
.then(data => {
  if (data.status === 'SUCCESS') {
    console.log('Event created:', data.data);
  } else if (data.status === 'VALIDATION_ERROR') {
    console.error('Validation errors:', data.data);
  } else {
    console.error('Error:', data.message);
  }
});
```

### Handling Specific Statuses

| Status | Action |
|--------|--------|
| SUCCESS | Display success message, update UI with data |
| VALIDATION_ERROR | Display validation errors, focus on invalid fields |
| UNAUTHORIZED | Redirect to login, clear auth token |
| FORBIDDEN | Show "Access Denied" message |
| NOT_FOUND | Show "Resource not found" message |
| CONFLICT | Show "Already exists" message |
| ERROR | Log to console, show generic error message |

## Response Wrapper Usage in Code

### Creating Success Responses

```java
// Simple success
return ResponseEntity.ok(ApiResponse.success("Operation completed"));

// With data
return ResponseEntity.ok(ApiResponse.success("Event created", eventData));

// Created status
return ResponseEntity.status(HttpStatus.CREATED)
    .body(ApiResponse.success("Event created successfully", eventData));
```

### Creating Error Responses

```java
// Not found
ApiResponse.notFound("Event not found");

// Unauthorized
ApiResponse.unauthorized("Invalid credentials");

// Forbidden
ApiResponse.forbidden("Not authorized");

// Conflict
ApiResponse.conflict("Resource already exists");

// Validation error
ApiResponse.validationError("Validation failed", errorMap);

// Generic error
ApiResponse.error("Something went wrong");
```

## Summary

The GlobalExceptionHandler automatically converts all exceptions to the standard ApiResponse format with appropriate HTTP status codes. This ensures:

✅ Consistent API response structure  
✅ Proper HTTP status codes  
✅ Detailed error messages  
✅ Field-level validation error reporting  
✅ Timestamp tracking for all responses  
✅ Type-safe response handling in clients
