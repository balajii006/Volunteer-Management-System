# VolunteerHub

A Spring Boot application for volunteer coordination built with modern Java technologies.

## Project Structure

```
src/
├── main/
│   ├── java/com/volunteerhub/
│   │   ├── controllers/           # REST API Controllers
│   │   ├── services/              # Business Logic Services
│   │   ├── repositories/          # Data Access Layer (JPA Repositories)
│   │   ├── entities/              # JPA Entities
│   │   ├── security/              # JWT & Security Components
│   │   ├── dtos/                  # Data Transfer Objects
│   │   ├── exceptions/            # Custom Exceptions
│   │   ├── config/                # Configuration Classes
│   │   └── VolunteerHubApplication.java
│   └── resources/
│       └── application.yml         # Application Configuration
└── test/java/com/volunteerhub/    # Test Classes
```

## Technology Stack

- **Java Version**: 17
- **Spring Boot**: 3.2.0
- **Database**: MySQL 8.0
- **ORM**: Spring Data JPA with Hibernate
- **Security**: Spring Security + JWT (JJWT)
- **Validation**: Jakarta Bean Validation
- **Build Tool**: Maven

## Key Features

- ✅ No Lombok - All getters, setters, and constructors written manually
- ✅ Layered Architecture: Controller → Service → Repository → Entity
- ✅ JWT-based Authentication
- ✅ Spring Security Integration
- ✅ Custom Exception Handling
- ✅ Input Validation
- ✅ MySQL Persistence

## Getting Started

### Prerequisites

- Java 17
- MySQL 8.0
- Maven 3.6+

### Installation

1. Create the database:
```sql
CREATE DATABASE volunteerhub;
```

2. Update `application.yml` with your MySQL credentials:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/volunteerhub?useSSL=False&allowPublicKeyRetrieval=True&serverTimezone=UTC
    username: <your_username>
    password: <your_password>
```

3. Build the project:
```bash
mvn clean install
```

4. Run the application:
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080/api`

## API Endpoints

### Authentication
- `POST /auth/register` - Register a new user
- `POST /auth/login` - Login user and get JWT token

### Users
- `GET /users` - Get all users
- `GET /users/{id}` - Get user by ID
- `GET /users/username/{username}` - Get user by username
- `POST /users` - Create new user
- `PUT /users/{id}` - Update user
- `DELETE /users/{id}` - Delete user

## Configuration

### JWT Configuration

Update the following properties in `application.yml`:

```yaml
jwt:
  secret: your_secret_key_at_least_32_characters_long
  expiration: 86400000  # 24 hours in milliseconds
```

### MySQL Configuration

Ensure your MySQL server is running and accessible with the configured credentials.

## Layered Architecture

### Controllers
Handles HTTP requests and responses. Gateway to the application.

### Services
Contains business logic and orchestrates between controllers and repositories.

### Repositories
Data access layer using Spring Data JPA.

### Entities
JPA-managed entity objects representing database tables.

### Security
JWT token generation, validation, and authentication filters.

### DTOs
Data transfer objects for request/response payloads.

### Exceptions
Custom exception classes for business logic errors.

### Config
Configuration classes for Spring Security, JPA, and other beans.

## Development Notes

- All classes follow manual constructor patterns without Lombok
- Use constructor injection for dependencies
- Properties are accessed through getters and setters
- Transactions are managed through `@Transactional` annotation
- Database credentials should be managed through environment variables or external properties

## License

Proprietary
