package com.volunteerhub.entities;

public enum Role {
    ROLE_VOLUNTEER("Volunteer"),
    ROLE_ORGANIZER("Organizer");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

}
