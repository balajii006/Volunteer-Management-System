package com.volunteerhub.entities;

public enum NotificationType {
    VOLUNTEER_JOINED("Volunteer Joined"),
    VOLUNTEER_CANCELLED("Volunteer Cancelled"),
    EVENT_CREATED("Event Created"),
    EVENT_UPDATED("Event Updated"),
    EVENT_CANCELLED("Event Cancelled"),
    EVENT_COMPLETED("Event Completed"),
    NEW_FEEDBACK("New Feedback Received");

    private final String displayName;

    NotificationType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
