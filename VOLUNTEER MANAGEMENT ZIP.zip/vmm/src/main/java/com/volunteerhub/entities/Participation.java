package com.volunteerhub.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "participations", uniqueConstraints = {
        @UniqueConstraint(columnNames = { "volunteer_id", "event_id" }, name = "uk_volunteer_event")
})
public class Participation extends BaseEntity {

    @NotNull(message = "Volunteer is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "volunteer_id", nullable = false)
    private User volunteer;

    @NotNull(message = "Event is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @NotNull(message = "Participation status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ParticipationStatus status;

    @Column(nullable = false, updatable = false)
    private LocalDateTime joinedAt;

    @Column(nullable = true)
    private LocalDateTime cancelledAt;

    @Column(nullable = false)
    private Boolean active = true;

    // Constructors
    public Participation() {
    }

    public Participation(User volunteer, Event event) {
        this.volunteer = volunteer;
        this.event = event;
        this.status = ParticipationStatus.JOINED;
        this.joinedAt = LocalDateTime.now();
        this.active = true;
    }

    public Participation(User volunteer, Event event, ParticipationStatus status) {
        this.volunteer = volunteer;
        this.event = event;
        this.status = status;
        this.joinedAt = LocalDateTime.now();
        this.active = true;
    }

    // Getters and Setters
    public User getVolunteer() {
        return volunteer;
    }

    public void setVolunteer(User volunteer) {
        this.volunteer = volunteer;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public ParticipationStatus getStatus() {
        return status;
    }

    public void setStatus(ParticipationStatus status) {
        this.status = status;
    }

    public LocalDateTime getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(LocalDateTime joinedAt) {
        this.joinedAt = joinedAt;
    }

    public LocalDateTime getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(LocalDateTime cancelledAt) {
        this.cancelledAt = cancelledAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
