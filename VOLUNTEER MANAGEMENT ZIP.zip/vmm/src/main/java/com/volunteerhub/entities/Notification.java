package com.volunteerhub.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications", indexes = {
        @Index(name = "idx_recipient_id", columnList = "recipient_id"),
        @Index(name = "idx_is_read", columnList = "is_read"),
        @Index(name = "idx_created_at", columnList = "created_at")
})
public class Notification extends BaseEntity {

    @NotNull(message = "Recipient is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @NotNull(message = "Notification type is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationType type;

    @NotNull(message = "Message is required")
    @Column(nullable = false, columnDefinition = "TEXT")
    private String message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "related_event_id")
    private Event relatedEvent;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "triggered_by_user_id")
    private User triggeredByUser;

    @NotNull(message = "Read status is required")
    @Column(name = "is_read", nullable = false)
    private Boolean isRead = false;

    @Column(nullable = true)
    private LocalDateTime readAt;

    @Column(nullable = false)
    private Boolean active = true;

    // Constructors
    public Notification() {
    }

    public Notification(User recipient, NotificationType type, String message) {
        this.recipient = recipient;
        this.type = type;
        this.message = message;
        this.isRead = false;
        this.active = true;
    }

    public Notification(User recipient, NotificationType type, String message, Event relatedEvent) {
        this.recipient = recipient;
        this.type = type;
        this.message = message;
        this.relatedEvent = relatedEvent;
        this.isRead = false;
        this.active = true;
    }

    public Notification(User recipient, NotificationType type, String message, Event relatedEvent,
            User triggeredByUser) {
        this.recipient = recipient;
        this.type = type;
        this.message = message;
        this.relatedEvent = relatedEvent;
        this.triggeredByUser = triggeredByUser;
        this.isRead = false;
        this.active = true;
    }

    // Getters and Setters
    public User getRecipient() {
        return recipient;
    }

    public void setRecipient(User recipient) {
        this.recipient = recipient;
    }

    public NotificationType getType() {
        return type;
    }

    public void setType(NotificationType type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Event getRelatedEvent() {
        return relatedEvent;
    }

    public void setRelatedEvent(Event relatedEvent) {
        this.relatedEvent = relatedEvent;
    }

    public User getTriggeredByUser() {
        return triggeredByUser;
    }

    public void setTriggeredByUser(User triggeredByUser) {
        this.triggeredByUser = triggeredByUser;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public LocalDateTime getReadAt() {
        return readAt;
    }

    public void setReadAt(LocalDateTime readAt) {
        this.readAt = readAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
