package com.volunteerhub.repositories;

import com.volunteerhub.entities.Feedback;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    // Query by event
    Page<Feedback> findByEventId(Long eventId, Pageable pageable);

    Page<Feedback> findByEventIdAndActive(Long eventId, Boolean active, Pageable pageable);

    // Query by volunteer
    Page<Feedback> findByVolunteerId(Long volunteerId, Pageable pageable);

    Page<Feedback> findByVolunteerIdAndActive(Long volunteerId, Boolean active, Pageable pageable);

    // Check if feedback exists
    Optional<Feedback> findByEventIdAndVolunteerId(Long eventId, Long volunteerId);

    boolean existsByEventIdAndVolunteerIdAndActive(Long eventId, Long volunteerId, Boolean active);

    // Count queries
    long countByEventIdAndActive(Long eventId, Boolean active);

    long countByVolunteerId(Long volunteerId);

    // Aggregate queries
    @Query("SELECT AVG(f.rating) FROM Feedback f WHERE f.event.id = :eventId AND f.active = true")
    Double getAverageRatingForEvent(@Param("eventId") Long eventId);

    @Query("SELECT f FROM Feedback f WHERE f.event.id = :eventId AND f.active = true ORDER BY f.createdAt DESC")
    List<Feedback> findEventFeedbackOrdered(@Param("eventId") Long eventId);

    @Query("SELECT AVG(f.rating) FROM Feedback f WHERE f.volunteer.id = :volunteerId AND f.active = true")
    Double getAverageRatingByVolunteer(@Param("volunteerId") Long volunteerId);

}
