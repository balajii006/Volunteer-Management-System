package com.volunteerhub.repositories;

import com.volunteerhub.entities.Event;
import com.volunteerhub.entities.EventStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    // Pagination queries
    Page<Event> findAll(Pageable pageable);

    Page<Event> findByActive(Boolean active, Pageable pageable);

    Page<Event> findByStatus(EventStatus status, Pageable pageable);

    Page<Event> findByOrganizerId(Long organizerId, Pageable pageable);

    Page<Event> findByTitleContainingIgnoreCase(String title, Pageable pageable);

    // Custom queries
    @Query("SELECT e FROM Event e WHERE e.organizer.id = :organizerId AND e.active = true")
    Page<Event> findActiveEventsByOrganizer(@Param("organizerId") Long organizerId, Pageable pageable);

    @Query("SELECT e FROM Event e WHERE e.status = :status AND e.active = true ORDER BY e.eventDate ASC")
    List<Event> findUpcomingEventsByStatus(@Param("status") EventStatus status);

    @Query("SELECT e FROM Event e WHERE e.eventDate >= :startDate AND e.eventDate <= :endDate AND e.active = true ORDER BY e.eventDate ASC")
    List<Event> findEventsByDateRange(@Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate);

    @Query("SELECT e FROM Event e WHERE e.currentVolunteers < e.maxVolunteers AND e.status = :status AND e.active = true")
    Page<Event> findEventsByAvailableSpots(@Param("status") EventStatus status, Pageable pageable);

    // Count queries
    long countByOrganizerId(Long organizerId);

    long countByStatus(EventStatus status);

    boolean existsByIdAndOrganizerId(Long eventId, Long organizerId);

}
