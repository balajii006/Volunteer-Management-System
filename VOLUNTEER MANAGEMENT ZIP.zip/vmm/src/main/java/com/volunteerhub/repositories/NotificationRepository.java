package com.volunteerhub.repositories;

import com.volunteerhub.entities.Notification;
import com.volunteerhub.entities.NotificationType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    // Query by recipient
    Page<Notification> findByRecipientId(Long recipientId, Pageable pageable);

    Page<Notification> findByRecipientIdAndActive(Long recipientId, Boolean active, Pageable pageable);

    // Query by read status
    Page<Notification> findByRecipientIdAndIsRead(Long recipientId, Boolean isRead, Pageable pageable);

    Page<Notification> findByRecipientIdAndIsReadAndActive(Long recipientId, Boolean isRead, Boolean active, Pageable pageable);

    // Query by type
    Page<Notification> findByRecipientIdAndType(Long recipientId, NotificationType type, Pageable pageable);

    // Count queries
    long countByRecipientId(Long recipientId);

    long countByRecipientIdAndIsRead(Long recipientId, Boolean isRead);

    long countByRecipientIdAndIsReadAndActive(Long recipientId, Boolean isRead, Boolean active);

    // Event-related queries
    @Query("SELECT n FROM Notification n WHERE n.recipient.id = :recipientId AND n.relatedEvent.id = :eventId AND n.active = true")
    List<Notification> findByRecipientAndEvent(@Param("recipientId") Long recipientId, @Param("eventId") Long eventId);

    @Query("SELECT n FROM Notification n WHERE n.recipient.id = :recipientId AND n.active = true ORDER BY n.createdAt DESC")
    Page<Notification> findRecentNotifications(@Param("recipientId") Long recipientId, Pageable pageable);

    @Query("SELECT n FROM Notification n WHERE n.recipient.id = :recipientId AND n.isRead = false AND n.active = true ORDER BY n.createdAt DESC")
    Page<Notification> findUnreadNotifications(@Param("recipientId") Long recipientId, Pageable pageable);

    // Cleanup queries
    @Query("SELECT n FROM Notification n WHERE n.createdAt < :date AND n.isRead = true")
    List<Notification> findOldReadNotifications(@Param("date") LocalDateTime date);

}
