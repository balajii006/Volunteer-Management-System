package com.volunteerhub.repositories;

import com.volunteerhub.entities.Participation;
import com.volunteerhub.entities.ParticipationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ParticipationRepository extends JpaRepository<Participation, Long> {

    // Query by volunteer
    Page<Participation> findByVolunteerId(Long volunteerId, Pageable pageable);

    Page<Participation> findByVolunteerIdAndActive(Long volunteerId, Boolean active, Pageable pageable);

    // Query by event
    Page<Participation> findByEventId(Long eventId, Pageable pageable);

    Page<Participation> findByEventIdAndActive(Long eventId, Boolean active, Pageable pageable);

    // Check participation
    Optional<Participation> findByEventIdAndVolunteerId(Long eventId, Long volunteerId);

    boolean existsByEventIdAndVolunteerIdAndActive(Long eventId, Long volunteerId, Boolean active);

    // Count queries
    long countByEventId(Long eventId);

    long countByEventIdAndStatus(Long eventId, ParticipationStatus status);

    long countByEventIdAndActive(Long eventId, Boolean active);

    long countByVolunteerId(Long volunteerId);

    // Status queries
    @Query("SELECT p FROM Participation p WHERE p.event.id = :eventId AND p.status = :status AND p.active = true")
    List<Participation> findByEventAndStatus(@Param("eventId") Long eventId,
            @Param("status") ParticipationStatus status);

    @Query("SELECT p FROM Participation p WHERE p.volunteer.id = :volunteerId AND p.event.id = :eventId")
    Optional<Participation> findByVolunteerAndEvent(@Param("volunteerId") Long volunteerId,
            @Param("eventId") Long eventId);

    @Query("SELECT p FROM Participation p WHERE p.event.id = :eventId AND p.active = true ORDER BY p.joinedAt ASC")
    Page<Participation> findActiveParticipationsByEventOrdered(@Param("eventId") Long eventId, Pageable pageable);

}
