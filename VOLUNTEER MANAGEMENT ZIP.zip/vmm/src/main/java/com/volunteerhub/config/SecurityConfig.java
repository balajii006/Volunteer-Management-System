package com.volunteerhub.config;

import com.volunteerhub.security.JwtAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // ✅ 1. Disable CSRF - Required for stateless JWT-based authentication
                .csrf(csrf -> csrf.disable())

                // ✅ 4. Use stateless session management - No cookies/sessions for JWT
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // ✅ 3. Configure authorization rules
                .authorizeHttpRequests(authz -> authz
                        // ✅ 2. Public auth endpoints - no authentication required
                        // Note: Don't include '/api' prefix in path matchers
                        // The servlet context-path (/api) is handled by the container
                        .requestMatchers("/auth/**").permitAll()

                        // Public user endpoints - viewable in browser
                        .requestMatchers("/users/**").permitAll()

                        // Actuator endpoints - public access
                        .requestMatchers("/actuator/**").permitAll()

                        // Other public endpoints (if needed)
                        .requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/swagger-ui.html").permitAll()
                        .requestMatchers("/actuator/health").permitAll()

                        // All other endpoints require JWT authentication
                        .anyRequest().authenticated())

                // ✅ 5. Add JwtAuthenticationFilter before UsernamePasswordAuthenticationFilter
                // This ensures JWT tokens are validated before Spring Security's default
                // authentication
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

}
