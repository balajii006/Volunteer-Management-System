package com.volunteerhub.config;

import com.volunteerhub.entities.User;
import com.volunteerhub.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        return new UserDetailsImpl(user);
    }

    public UserDetails loadUserById(Long id) throws UsernameNotFoundException {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with id: " + id));

        return new UserDetailsImpl(user);
    }

    public static class UserDetailsImpl implements UserDetails {

        private static final long serialVersionUID = 1L;

        private Long id;
        private String username;
        private String password;
        private Boolean active;
        private Collection<? extends GrantedAuthority> authorities;

        public UserDetailsImpl(Long id, String username, String password, Boolean active,
                Collection<? extends GrantedAuthority> authorities) {
            this.id = id;
            this.username = username;
            this.password = password;
            this.active = active;
            this.authorities = authorities;
        }

        public UserDetailsImpl(User user) {
            this.id = user.getId();
            this.username = user.getUsername();
            this.password = user.getPassword();
            this.active = user.getActive();
            Set<GrantedAuthority> authorities = new HashSet<>();
            if (user.getRole() != null) {
                authorities.add(new SimpleGrantedAuthority(user.getRole().toString()));
            } else {
                authorities.add(new SimpleGrantedAuthority("ROLE_VOLUNTEER"));
            }
            this.authorities = authorities;
        }

        public Long getId() {
            return id;
        }

        @Override
        public String getUsername() {
            return username;
        }

        @Override
        public String getPassword() {
            return password;
        }

        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
            return authorities;
        }

        @Override
        public boolean isAccountNonExpired() {
            return true;
        }

        @Override
        public boolean isAccountNonLocked() {
            return true;
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return true;
        }

        @Override
        public boolean isEnabled() {
            return active;
        }
    }

}
