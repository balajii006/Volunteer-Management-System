package com.volunteerhub.security;

import java.util.Arrays;
import java.util.List;

public class JwtConstants {

    public static final String JWT_HEADER = "Authorization";
    public static final String JWT_BEARER = "Bearer ";
    public static final String JWT_CLAIMS_ROLES = "roles";

    public static final List<String> PUBLIC_ENDPOINTS = Arrays.asList(
            "/auth/login",
            "/auth/register",
            "/swagger-ui/**",
            "/v3/api-docs/**",
            "/swagger-ui.html");

}
