package com.volunteerhub.controllers;

import com.volunteerhub.dtos.CreateEventDTO;
import com.volunteerhub.dtos.EventResponseDTO;
import com.volunteerhub.dtos.UpdateEventDTO;
import com.volunteerhub.entities.EventStatus;
import com.volunteerhub.services.EventService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/events")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    /**
     * Get all active events with pagination.
     *
     * @param page the page number (default: 0)
     * @param size the page size (default: 10)
     * @param sort the sort criteria (default: id descending)
     * @return a page of events
     */
    @GetMapping
    public ResponseEntity<Page<EventResponseDTO>> getAllEvents(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            @RequestParam(name = "sort", defaultValue = "id,desc") String sort) {

        String[] sortParts = sort.split(",");
        Sort.Direction direction = Sort.Direction.ASC;
        String sortBy = "id";

        if (sortParts.length > 0) {
            sortBy = sortParts[0];
        }
        if (sortParts.length > 1 && sortParts[1].equalsIgnoreCase("desc")) {
            direction = Sort.Direction.DESC;
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        Page<EventResponseDTO> events = eventService.getAllEvents(pageable);

        return ResponseEntity.ok(events);
    }

    /**
     * Get a specific event by ID.
     *
     * @param eventId the event ID
     * @return the event details
     */
    @GetMapping("/{eventId}")
    public ResponseEntity<EventResponseDTO> getEventById(@PathVariable Long eventId) {
        EventResponseDTO event = eventService.getEventById(eventId);
        return ResponseEntity.ok(event);
    }

    /**
     * Get all events organized by a specific user.
     *
     * @param organizerId the organizer ID
     * @param page        the page number (default: 0)
     * @param size        the page size (default: 10)
     * @return a page of events organized by the specified user
     */
    @GetMapping("/organizer/{organizerId}")
    public ResponseEntity<Page<EventResponseDTO>> getEventsByOrganizer(
            @PathVariable Long organizerId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "eventDate"));
        Page<EventResponseDTO> events = eventService.getEventsByOrganizer(organizerId, pageable);

        return ResponseEntity.ok(events);
    }

    /**
     * Get all events by status.
     *
     * @param status the event status
     * @param page   the page number (default: 0)
     * @param size   the page size (default: 10)
     * @return a page of events with the specified status
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<Page<EventResponseDTO>> getEventsByStatus(
            @PathVariable String status,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size) {

        EventStatus eventStatus = EventStatus.valueOf(status.toUpperCase());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "eventDate"));
        Page<EventResponseDTO> events = eventService.getEventsByStatus(eventStatus, pageable);

        return ResponseEntity.ok(events);
    }

    /**
     * Get events with available volunteer spots.
     *
     * @param page the page number (default: 0)
     * @param size the page size (default: 10)
     * @return a page of events with available spots
     */
    @GetMapping("/available-spots")
    public ResponseEntity<Page<EventResponseDTO>> getEventsWithAvailableSpots(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "eventDate"));
        Page<EventResponseDTO> events = eventService.getEventsWithAvailableSpots(pageable);

        return ResponseEntity.ok(events);
    }

    /**
     * Create a new event. Only organizers can create events.
     *
     * @param createEventDTO the event creation data
     * @param authentication the current authenticated user
     * @return the created event
     */
    @PostMapping
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<EventResponseDTO> createEvent(
            @Valid @RequestBody CreateEventDTO createEventDTO,
            Authentication authentication) {

        Long organizerId = Long.parseLong(authentication.getName());
        EventResponseDTO createdEvent = eventService.createEvent(createEventDTO, organizerId);

        return ResponseEntity.status(HttpStatus.CREATED).body(createdEvent);
    }

    /**
     * Update an event. Only the event organizer can update.
     *
     * @param eventId        the event ID
     * @param updateEventDTO the updated event data
     * @param authentication the current authenticated user
     * @return the updated event
     */
    @PutMapping("/{eventId}")
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<EventResponseDTO> updateEvent(
            @PathVariable Long eventId,
            @Valid @RequestBody UpdateEventDTO updateEventDTO,
            Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        EventResponseDTO updatedEvent = eventService.updateEvent(eventId, updateEventDTO, userId);

        return ResponseEntity.ok(updatedEvent);
    }

    /**
     * Delete an event. Only the event organizer can delete.
     *
     * @param eventId        the event ID
     * @param authentication the current authenticated user
     * @return HTTP 204 No Content on success
     */
    @DeleteMapping("/{eventId}")
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Void> deleteEvent(
            @PathVariable Long eventId,
            Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        eventService.deleteEvent(eventId, userId);

        return ResponseEntity.noContent().build();
    }

    /**
     * Update event status. Only the event organizer can change status.
     *
     * @param eventId        the event ID
     * @param status         the new status
     * @param authentication the current authenticated user
     * @return the updated event
     */
    @PatchMapping("/{eventId}/status")
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<EventResponseDTO> updateEventStatus(
            @PathVariable Long eventId,
            @RequestParam String status,
            Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        EventStatus eventStatus = EventStatus.valueOf(status.toUpperCase());
        EventResponseDTO updatedEvent = eventService.updateEventStatus(eventId, eventStatus, userId);

        return ResponseEntity.ok(updatedEvent);
    }

}
