package com.volunteerhub.controllers;

import com.volunteerhub.dtos.NotificationResponseDTO;
import com.volunteerhub.services.NotificationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    /**
     * Get all notifications for the current user with pagination.
     *
     * @param page           the page number (default: 0)
     * @param size           the page size (default: 10)
     * @param authentication the current authenticated user
     * @return a page of notifications
     */
    @GetMapping
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Page<NotificationResponseDTO>> getUserNotifications(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<NotificationResponseDTO> notifications = notificationService.getUserNotifications(userId, pageable);

        return ResponseEntity.ok(notifications);
    }

    /**
     * Get unread notifications for the current user with pagination.
     *
     * @param page           the page number (default: 0)
     * @param size           the page size (default: 10)
     * @param authentication the current authenticated user
     * @return a page of unread notifications
     */
    @GetMapping("/unread")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Page<NotificationResponseDTO>> getUnreadNotifications(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<NotificationResponseDTO> notifications = notificationService.getUnreadNotifications(userId, pageable);

        return ResponseEntity.ok(notifications);
    }

    /**
     * Get the count of unread notifications for the current user.
     *
     * @param authentication the current authenticated user
     * @return the count of unread notifications
     */
    @GetMapping("/unread/count")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Map<String, Long>> getUnreadCount(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        long unreadCount = notificationService.getUnreadCount(userId);

        Map<String, Long> response = new HashMap<>();
        response.put("unreadCount", unreadCount);

        return ResponseEntity.ok(response);
    }

    /**
     * Mark a notification as read.
     *
     * @param notificationId the ID of the notification
     * @return the updated notification
     */
    @PutMapping("/{notificationId}/read")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<NotificationResponseDTO> markAsRead(@PathVariable Long notificationId) {
        NotificationResponseDTO notification = notificationService.markAsRead(notificationId);
        return ResponseEntity.ok(notification);
    }

    /**
     * Mark all unread notifications as read for the current user.
     *
     * @param authentication the current authenticated user
     * @return the count of marked notifications
     */
    @PutMapping("/read-all")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Map<String, Long>> markAllAsRead(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        long markedCount = notificationService.markAllAsRead(userId);

        Map<String, Long> response = new HashMap<>();
        response.put("markedCount", markedCount);

        return ResponseEntity.ok(response);
    }

    /**
     * Delete a notification.
     *
     * @param notificationId the ID of the notification to delete
     * @return HTTP 204 No Content on success
     */
    @DeleteMapping("/{notificationId}")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Void> deleteNotification(@PathVariable Long notificationId) {
        notificationService.deleteNotification(notificationId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Delete all notifications for the current user.
     *
     * @param authentication the current authenticated user
     * @return the count of deleted notifications
     */
    @DeleteMapping
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Map<String, Long>> deleteAllNotifications(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        long deletedCount = notificationService.deleteAllUserNotifications(userId);

        Map<String, Long> response = new HashMap<>();
        response.put("deletedCount", deletedCount);

        return ResponseEntity.ok(response);
    }

}
