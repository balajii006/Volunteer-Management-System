package com.volunteerhub.controllers;

import com.volunteerhub.dtos.CreateFeedbackDTO;
import com.volunteerhub.dtos.FeedbackResponseDTO;
import com.volunteerhub.services.FeedbackService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class FeedbackController {

    private final FeedbackService feedbackService;

    public FeedbackController(FeedbackService feedbackService) {
        this.feedbackService = feedbackService;
    }

    /**
     * Create feedback for an event.
     *
     * @param createFeedbackDTO the feedback creation data
     * @param authentication    the current authenticated user
     * @return the created feedback
     */
    @PostMapping("/feedback")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<FeedbackResponseDTO> createFeedback(
            @Valid @RequestBody CreateFeedbackDTO createFeedbackDTO,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        FeedbackResponseDTO feedback = feedbackService.createFeedback(createFeedbackDTO, volunteerId);

        return ResponseEntity.status(HttpStatus.CREATED).body(feedback);
    }

    /**
     * Get all feedback for an event. Only the event organizer can view.
     *
     * @param eventId        the ID of the event
     * @param page           the page number (default: 0)
     * @param size           the page size (default: 10)
     * @param authentication the current authenticated user
     * @return a page of feedback for the event
     */
    @GetMapping("/events/{eventId}/feedback")
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Page<FeedbackResponseDTO>> getEventFeedback(
            @PathVariable Long eventId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            Authentication authentication) {

        Long organizerId = Long.parseLong(authentication.getName());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<FeedbackResponseDTO> feedbacks = feedbackService.getEventFeedback(eventId, organizerId, pageable);

        return ResponseEntity.ok(feedbacks);
    }

    /**
     * Get the average rating for an event.
     *
     * @param eventId the ID of the event
     * @return the average rating and feedback count
     */
    @GetMapping("/events/{eventId}/feedback/average-rating")
    public ResponseEntity<Map<String, Object>> getAverageRating(@PathVariable Long eventId) {
        Double averageRating = feedbackService.getAverageRating(eventId);
        long feedbackCount = feedbackService.getFeedbackCount(eventId);

        Map<String, Object> response = new HashMap<>();
        response.put("eventId", eventId);
        response.put("averageRating", averageRating);
        response.put("feedbackCount", feedbackCount);

        return ResponseEntity.ok(response);
    }

    /**
     * Get all feedback provided by the current user.
     *
     * @param page           the page number (default: 0)
     * @param size           the page size (default: 10)
     * @param authentication the current authenticated user
     * @return a page of feedback provided by the user
     */
    @GetMapping("/feedback/my-feedback")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Page<FeedbackResponseDTO>> getMyFeedback(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<FeedbackResponseDTO> feedbacks = feedbackService.getVolunteerFeedback(volunteerId, pageable);

        return ResponseEntity.ok(feedbacks);
    }

    /**
     * Get feedback provided by a specific volunteer.
     *
     * @param volunteerId the ID of the volunteer
     * @param page        the page number (default: 0)
     * @param size        the page size (default: 10)
     * @return a page of feedback provided by the volunteer
     */
    @GetMapping("/feedback/volunteer/{volunteerId}")
    public ResponseEntity<Page<FeedbackResponseDTO>> getVolunteerFeedback(
            @PathVariable Long volunteerId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<FeedbackResponseDTO> feedbacks = feedbackService.getVolunteerFeedback(volunteerId, pageable);

        return ResponseEntity.ok(feedbacks);
    }

    /**
     * Get the average rating contributed by a volunteer.
     *
     * @param volunteerId the ID of the volunteer
     * @return the average rating and count
     */
    @GetMapping("/feedback/volunteer/{volunteerId}/average-rating")
    public ResponseEntity<Map<String, Object>> getVolunteerAverageRating(@PathVariable Long volunteerId) {
        Double averageRating = feedbackService.getVolunteerAverageRating(volunteerId);
        long feedbackCount = feedbackService.getFeedbackCount(volunteerId);

        Map<String, Object> response = new HashMap<>();
        response.put("volunteerId", volunteerId);
        response.put("averageRating", averageRating);
        response.put("feedbackCount", feedbackCount);

        return ResponseEntity.ok(response);
    }

    /**
     * Delete feedback. Only the feedback author can delete.
     *
     * @param feedbackId     the ID of the feedback to delete
     * @param authentication the current authenticated user
     * @return HTTP 204 No Content on success
     */
    @DeleteMapping("/feedback/{feedbackId}")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Void> deleteFeedback(
            @PathVariable Long feedbackId,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        feedbackService.deleteFeedback(feedbackId, volunteerId);

        return ResponseEntity.noContent().build();
    }

}
