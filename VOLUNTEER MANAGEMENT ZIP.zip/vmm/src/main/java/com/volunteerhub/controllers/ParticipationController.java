package com.volunteerhub.controllers;

import com.volunteerhub.dtos.ParticipationResponseDTO;
import com.volunteerhub.services.ParticipationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/events")
public class ParticipationController {

    private final ParticipationService participationService;

    public ParticipationController(ParticipationService participationService) {
        this.participationService = participationService;
    }

    /**
     * Join an event as a volunteer.
     *
     * @param eventId        the ID of the event to join
     * @param authentication the current authenticated user
     * @return the participation record created
     */
    @PostMapping("/{eventId}/join")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<ParticipationResponseDTO> joinEvent(
            @PathVariable Long eventId,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        ParticipationResponseDTO participation = participationService.joinEvent(eventId, volunteerId);

        return ResponseEntity.status(HttpStatus.CREATED).body(participation);
    }

    /**
     * Cancel participation in an event.
     *
     * @param eventId        the ID of the event
     * @param authentication the current authenticated user
     * @return HTTP 204 No Content on success
     */
    @DeleteMapping("/{eventId}/cancel")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Void> cancelParticipation(
            @PathVariable Long eventId,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        participationService.cancelParticipation(eventId, volunteerId);

        return ResponseEntity.noContent().build();
    }

    /**
     * Get all participants of an event. Only the event organizer can view.
     *
     * @param eventId        the ID of the event
     * @param page           the page number (default: 0)
     * @param size           the page size (default: 10)
     * @param authentication the current authenticated user
     * @return a page of participants
     */
    @GetMapping("/{eventId}/participants")
    @PreAuthorize("hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Page<ParticipationResponseDTO>> getEventParticipants(
            @PathVariable Long eventId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            Authentication authentication) {

        Long organizerId = Long.parseLong(authentication.getName());
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "joinedAt"));
        Page<ParticipationResponseDTO> participants = participationService.getEventParticipants(eventId, organizerId,
                pageable);

        return ResponseEntity.ok(participants);
    }

    /**
     * Check if the current user is participating in an event.
     *
     * @param eventId        the ID of the event
     * @param authentication the current authenticated user
     * @return HTTP 200 if participating, 404 if not
     */
    @GetMapping("/{eventId}/check-participation")
    @PreAuthorize("hasRole('ROLE_VOLUNTEER') or hasRole('ROLE_ORGANIZER')")
    public ResponseEntity<Boolean> checkParticipation(
            @PathVariable Long eventId,
            Authentication authentication) {

        Long volunteerId = Long.parseLong(authentication.getName());
        boolean isParticipating = participationService.isVolunteerParticipating(eventId, volunteerId);

        return ResponseEntity.ok(isParticipating);
    }

}
