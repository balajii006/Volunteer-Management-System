package com.volunteerhub.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;

public class CreateFeedbackDTO {

    @NotNull(message = "Event ID is required")
    private Long eventId;

    @NotNull(message = "Rating is required")
    @Min(value = 1, message = "Rating must be at least 1")
    @Max(value = 5, message = "Rating must not exceed 5")
    private Integer rating;

    private String comment;

    // Constructors
    public CreateFeedbackDTO() {
    }

    public CreateFeedbackDTO(Long eventId, Integer rating) {
        this.eventId = eventId;
        this.rating = rating;
    }

    public CreateFeedbackDTO(Long eventId, Integer rating, String comment) {
        this.eventId = eventId;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters and Setters
    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}
