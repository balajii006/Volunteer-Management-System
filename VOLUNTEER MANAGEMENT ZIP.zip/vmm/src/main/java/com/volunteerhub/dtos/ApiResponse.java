package com.volunteerhub.dtos;

public class ApiResponse<T> {

    private String status;

    private String message;

    private T data;

    private Long timestamp;

    // Constructors
    public ApiResponse() {
        this.timestamp = System.currentTimeMillis();
    }

    public ApiResponse(String status, String message) {
        this.status = status;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
    }

    public ApiResponse(String status, String message, T data) {
        this.status = status;
        this.message = message;
        this.data = data;
        this.timestamp = System.currentTimeMillis();
    }

    // Static factory methods
    public static <T> ApiResponse<T> success(String message) {
        return new ApiResponse<>("SUCCESS", message);
    }

    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>("SUCCESS", message, data);
    }

    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>("ERROR", message);
    }

    public static <T> ApiResponse<T> error(String message, T data) {
        return new ApiResponse<>("ERROR", message, data);
    }

    public static <T> ApiResponse<T> validationError(String message) {
        return new ApiResponse<>("VALIDATION_ERROR", message);
    }

    public static <T> ApiResponse<T> validationError(String message, T data) {
        return new ApiResponse<>("VALIDATION_ERROR", message, data);
    }

    public static <T> ApiResponse<T> unauthorized(String message) {
        return new ApiResponse<>("UNAUTHORIZED", message);
    }

    public static <T> ApiResponse<T> forbidden(String message) {
        return new ApiResponse<>("FORBIDDEN", message);
    }

    public static <T> ApiResponse<T> notFound(String message) {
        return new ApiResponse<>("NOT_FOUND", message);
    }

    public static <T> ApiResponse<T> conflict(String message) {
        return new ApiResponse<>("CONFLICT", message);
    }

    public static <T> ApiResponse<T> conflict(String message, T data) {
        return new ApiResponse<>("CONFLICT", message, data);
    }

    // Getters and Setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

}
