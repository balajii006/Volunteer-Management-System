package com.volunteerhub.dtos;

public class CreateParticipationDTO {

    private Long eventId;

    // Constructors
    public CreateParticipationDTO() {
    }

    public CreateParticipationDTO(Long eventId) {
        this.eventId = eventId;
    }

    // Getters and Setters
    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

}
