package com.volunteerhub.dtos;

import java.time.LocalDateTime;

public class NotificationResponseDTO {

    private Long id;

    private String type;

    private String message;

    private Long relatedEventId;

    private String relatedEventTitle;

    private Long triggeredByUserId;

    private String triggeredByUserName;

    private Boolean isRead;

    private LocalDateTime readAt;

    private LocalDateTime createdAt;

    // Constructors
    public NotificationResponseDTO() {
    }

    public NotificationResponseDTO(Long id, String type, String message, LocalDateTime createdAt) {
        this.id = id;
        this.type = type;
        this.message = message;
        this.createdAt = createdAt;
        this.isRead = false;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Long getRelatedEventId() {
        return relatedEventId;
    }

    public void setRelatedEventId(Long relatedEventId) {
        this.relatedEventId = relatedEventId;
    }

    public String getRelatedEventTitle() {
        return relatedEventTitle;
    }

    public void setRelatedEventTitle(String relatedEventTitle) {
        this.relatedEventTitle = relatedEventTitle;
    }

    public Long getTriggeredByUserId() {
        return triggeredByUserId;
    }

    public void setTriggeredByUserId(Long triggeredByUserId) {
        this.triggeredByUserId = triggeredByUserId;
    }

    public String getTriggeredByUserName() {
        return triggeredByUserName;
    }

    public void setTriggeredByUserName(String triggeredByUserName) {
        this.triggeredByUserName = triggeredByUserName;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public LocalDateTime getReadAt() {
        return readAt;
    }

    public void setReadAt(LocalDateTime readAt) {
        this.readAt = readAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

}
