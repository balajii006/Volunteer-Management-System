package com.volunteerhub.dtos;

import java.time.LocalDateTime;

public class ParticipationResponseDTO {

    private Long id;

    private Long volunteerId;

    private String volunteerName;

    private Long eventId;

    private String eventTitle;

    private String status;

    private LocalDateTime joinedAt;

    private LocalDateTime cancelledAt;

    private Boolean active;

    // Constructors
    public ParticipationResponseDTO() {
    }

    public ParticipationResponseDTO(Long id, Long volunteerId, String volunteerName,
            Long eventId, String eventTitle, String status, LocalDateTime joinedAt) {
        this.id = id;
        this.volunteerId = volunteerId;
        this.volunteerName = volunteerName;
        this.eventId = eventId;
        this.eventTitle = eventTitle;
        this.status = status;
        this.joinedAt = joinedAt;
        this.active = true;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVolunteerId() {
        return volunteerId;
    }

    public void setVolunteerId(Long volunteerId) {
        this.volunteerId = volunteerId;
    }

    public String getVolunteerName() {
        return volunteerName;
    }

    public void setVolunteerName(String volunteerName) {
        this.volunteerName = volunteerName;
    }

    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(LocalDateTime joinedAt) {
        this.joinedAt = joinedAt;
    }

    public LocalDateTime getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(LocalDateTime cancelledAt) {
        this.cancelledAt = cancelledAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
