package com.volunteerhub.services;

import com.volunteerhub.dtos.CreateFeedbackDTO;
import com.volunteerhub.dtos.FeedbackResponseDTO;
import com.volunteerhub.entities.Event;
import com.volunteerhub.entities.Feedback;
import com.volunteerhub.entities.User;
import com.volunteerhub.exceptions.DuplicateResourceException;
import com.volunteerhub.exceptions.ResourceNotFoundException;
import com.volunteerhub.exceptions.UnauthorizedException;
import com.volunteerhub.repositories.EventRepository;
import com.volunteerhub.repositories.FeedbackRepository;
import com.volunteerhub.repositories.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final EventRepository eventRepository;
    private final UserRepository userRepository;

    public FeedbackService(FeedbackRepository feedbackRepository,
            EventRepository eventRepository,
            UserRepository userRepository) {
        this.feedbackRepository = feedbackRepository;
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
    }

    /**
     * Create feedback for an event. A volunteer can only leave one feedback per
     * event.
     *
     * @param createFeedbackDTO the feedback creation data
     * @param volunteerId       the ID of the volunteer providing feedback
     * @return the created feedback as FeedbackResponseDTO
     * @throws ResourceNotFoundException  if event or volunteer not found
     * @throws DuplicateResourceException if volunteer already provided feedback for
     *                                    this event
     */
    public FeedbackResponseDTO createFeedback(CreateFeedbackDTO createFeedbackDTO, Long volunteerId) {
        // Verify volunteer exists
        User volunteer = userRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException("Volunteer not found with ID: " + volunteerId));

        // Verify event exists
        Event event = eventRepository.findById(createFeedbackDTO.getEventId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Event not found with ID: " + createFeedbackDTO.getEventId()));

        // Prevent duplicate feedback
        boolean alreadyProvidedFeedback = feedbackRepository.existsByEventIdAndVolunteerIdAndActive(
                createFeedbackDTO.getEventId(), volunteerId, true);
        if (alreadyProvidedFeedback) {
            throw new DuplicateResourceException("You have already provided feedback for this event.");
        }

        // Create feedback
        Feedback feedback = new Feedback();
        feedback.setVolunteer(volunteer);
        feedback.setEvent(event);
        feedback.setRating(createFeedbackDTO.getRating());
        feedback.setComment(createFeedbackDTO.getComment());
        feedback.setActive(true);

        Feedback savedFeedback = feedbackRepository.save(feedback);
        return convertToResponseDTO(savedFeedback);
    }

    /**
     * Get all feedback for an event. Only the event organizer can view.
     *
     * @param eventId     the ID of the event
     * @param organizerId the ID of the requesting user (must be the organizer)
     * @param pageable    pagination information
     * @return a page of feedback for the event
     * @throws ResourceNotFoundException if event not found
     * @throws UnauthorizedException     if requester is not the event organizer
     */
    @Transactional(readOnly = true)
    public Page<FeedbackResponseDTO> getEventFeedback(Long eventId, Long organizerId, Pageable pageable) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Authorization check: only organizer can view event feedback
        if (!event.getOrganizer().getId().equals(organizerId)) {
            throw new UnauthorizedException(
                    "You are not authorized to view feedback for this event. Only the organizer can view event feedback.");
        }

        Page<Feedback> feedbacks = feedbackRepository.findByEventIdAndActive(eventId, true, pageable);
        return feedbacks.map(this::convertToResponseDTO);
    }

    /**
     * Get all feedback provided by a volunteer.
     *
     * @param volunteerId the ID of the volunteer
     * @param pageable    pagination information
     * @return a page of feedback provided by the volunteer
     */
    @Transactional(readOnly = true)
    public Page<FeedbackResponseDTO> getVolunteerFeedback(Long volunteerId, Pageable pageable) {
        Page<Feedback> feedbacks = feedbackRepository.findByVolunteerIdAndActive(volunteerId, true, pageable);
        return feedbacks.map(this::convertToResponseDTO);
    }

    /**
     * Get the average rating for an event.
     *
     * @param eventId the ID of the event
     * @return the average rating, or 0.0 if no feedback exists
     * @throws ResourceNotFoundException if event not found
     */
    @Transactional(readOnly = true)
    public Double getAverageRating(Long eventId) {
        // Verify event exists
        if (!eventRepository.existsById(eventId)) {
            throw new ResourceNotFoundException("Event not found with ID: " + eventId);
        }

        Double average = feedbackRepository.getAverageRatingForEvent(eventId);
        return average != null ? average : 0.0;
    }

    /**
     * Get the count of feedback for an event.
     *
     * @param eventId the ID of the event
     * @return the count of feedback for the event
     */
    @Transactional(readOnly = true)
    public long getFeedbackCount(Long eventId) {
        return feedbackRepository.countByEventIdAndActive(eventId, true);
    }

    /**
     * Get the average rating contributed by a volunteer.
     *
     * @param volunteerId the ID of the volunteer
     * @return the average rating given by the volunteer
     */
    @Transactional(readOnly = true)
    public Double getVolunteerAverageRating(Long volunteerId) {
        Double average = feedbackRepository.getAverageRatingByVolunteer(volunteerId);
        return average != null ? average : 0.0;
    }

    /**
     * Get a specific feedback record.
     *
     * @param feedbackId the ID of the feedback
     * @return the feedback as FeedbackResponseDTO
     * @throws ResourceNotFoundException if feedback not found
     */
    @Transactional(readOnly = true)
    public FeedbackResponseDTO getFeedbackById(Long feedbackId) {
        Feedback feedback = feedbackRepository.findById(feedbackId)
                .orElseThrow(() -> new ResourceNotFoundException("Feedback not found with ID: " + feedbackId));
        return convertToResponseDTO(feedback);
    }

    /**
     * Delete/mark feedback as inactive.
     *
     * @param feedbackId  the ID of the feedback to delete
     * @param volunteerId the ID of the user attempting deletion (must be the
     *                    feedback author)
     * @throws ResourceNotFoundException if feedback not found
     * @throws UnauthorizedException     if user is not the feedback author
     */
    public void deleteFeedback(Long feedbackId, Long volunteerId) {
        Feedback feedback = feedbackRepository.findById(feedbackId)
                .orElseThrow(() -> new ResourceNotFoundException("Feedback not found with ID: " + feedbackId));

        // Authorization check: only feedback author can delete
        if (!feedback.getVolunteer().getId().equals(volunteerId)) {
            throw new UnauthorizedException(
                    "You are not authorized to delete this feedback. Only the author can delete their feedback.");
        }

        feedback.setActive(false);
        feedbackRepository.save(feedback);
    }

    /**
     * Convert Feedback entity to FeedbackResponseDTO.
     *
     * @param feedback the feedback entity
     * @return the feedback as FeedbackResponseDTO
     */
    private FeedbackResponseDTO convertToResponseDTO(Feedback feedback) {
        FeedbackResponseDTO dto = new FeedbackResponseDTO();
        dto.setId(feedback.getId());
        dto.setVolunteerId(feedback.getVolunteer().getId());
        dto.setVolunteerName(feedback.getVolunteer().getFirstName() + " " + feedback.getVolunteer().getLastName());
        dto.setEventId(feedback.getEvent().getId());
        dto.setEventTitle(feedback.getEvent().getTitle());
        dto.setRating(feedback.getRating());
        dto.setComment(feedback.getComment());
        dto.setCreatedAt(feedback.getCreatedAt());
        dto.setUpdatedAt(feedback.getUpdatedAt());
        dto.setActive(feedback.getActive());
        return dto;
    }

}
