package com.volunteerhub.services;

import com.volunteerhub.dtos.NotificationResponseDTO;
import com.volunteerhub.entities.Event;
import com.volunteerhub.entities.Notification;
import com.volunteerhub.entities.NotificationType;
import com.volunteerhub.entities.User;
import com.volunteerhub.exceptions.ResourceNotFoundException;
import com.volunteerhub.repositories.NotificationRepository;
import com.volunteerhub.repositories.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public NotificationService(NotificationRepository notificationRepository,
            UserRepository userRepository) {
        this.notificationRepository = notificationRepository;
        this.userRepository = userRepository;
    }

    /**
     * Create and send a notification to a user.
     *
     * @param recipientId the ID of the notification recipient
     * @param type        the type of notification
     * @param message     the notification message
     * @return the created notification as NotificationResponseDTO
     * @throws ResourceNotFoundException if recipient not found
     */
    public NotificationResponseDTO createNotification(Long recipientId, NotificationType type, String message) {
        User recipient = userRepository.findById(recipientId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + recipientId));

        Notification notification = new Notification(recipient, type, message);
        Notification savedNotification = notificationRepository.save(notification);

        return convertToResponseDTO(savedNotification);
    }

    /**
     * Create notification with related event and triggering user.
     *
     * @param recipientId     the ID of the notification recipient
     * @param type            the type of notification
     * @param message         the notification message
     * @param event           the related event
     * @param triggeredByUser the user who triggered the notification
     * @return the created notification as NotificationResponseDTO
     * @throws ResourceNotFoundException if recipient not found
     */
    public NotificationResponseDTO createNotification(Long recipientId, NotificationType type, String message,
            Event event, User triggeredByUser) {
        User recipient = userRepository.findById(recipientId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + recipientId));

        Notification notification = new Notification(recipient, type, message, event, triggeredByUser);
        Notification savedNotification = notificationRepository.save(notification);

        return convertToResponseDTO(savedNotification);
    }

    /**
     * Get all notifications for a user with pagination.
     *
     * @param userId   the ID of the user
     * @param pageable pagination information
     * @return a page of notifications
     */
    @Transactional(readOnly = true)
    public Page<NotificationResponseDTO> getUserNotifications(Long userId, Pageable pageable) {
        Page<Notification> notifications = notificationRepository.findRecentNotifications(userId, pageable);
        return notifications.map(this::convertToResponseDTO);
    }

    /**
     * Get unread notifications for a user with pagination.
     *
     * @param userId   the ID of the user
     * @param pageable pagination information
     * @return a page of unread notifications
     */
    @Transactional(readOnly = true)
    public Page<NotificationResponseDTO> getUnreadNotifications(Long userId, Pageable pageable) {
        Page<Notification> notifications = notificationRepository.findUnreadNotifications(userId, pageable);
        return notifications.map(this::convertToResponseDTO);
    }

    /**
     * Mark a notification as read.
     *
     * @param notificationId the ID of the notification
     * @return the updated notification as NotificationResponseDTO
     * @throws ResourceNotFoundException if notification not found
     */
    public NotificationResponseDTO markAsRead(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with ID: " + notificationId));

        notification.setIsRead(true);
        notification.setReadAt(LocalDateTime.now());

        Notification updatedNotification = notificationRepository.save(notification);
        return convertToResponseDTO(updatedNotification);
    }

    /**
     * Mark all unread notifications as read for a user.
     *
     * @param userId the ID of the user
     * @return the count of marked notifications
     */
    public long markAllAsRead(Long userId) {
        // Get all unread notifications
        List<Notification> unreadNotifications = notificationRepository
                .findUnreadNotifications(userId, org.springframework.data.domain.PageRequest.of(0, Integer.MAX_VALUE))
                .getContent();

        LocalDateTime now = LocalDateTime.now();
        for (Notification notification : unreadNotifications) {
            notification.setIsRead(true);
            notification.setReadAt(now);
        }

        notificationRepository.saveAll(unreadNotifications);
        return unreadNotifications.size();
    }

    /**
     * Get the count of unread notifications for a user.
     *
     * @param userId the ID of the user
     * @return the count of unread notifications
     */
    @Transactional(readOnly = true)
    public long getUnreadCount(Long userId) {
        return notificationRepository.countByRecipientIdAndIsReadAndActive(userId, false, true);
    }

    /**
     * Get notifications for a specific event.
     *
     * @param userId  the ID of the user
     * @param eventId the ID of the event
     * @return list of notifications related to the event
     */
    @Transactional(readOnly = true)
    public List<NotificationResponseDTO> getEventNotifications(Long userId, Long eventId) {
        List<Notification> notifications = notificationRepository.findByRecipientAndEvent(userId, eventId);
        return notifications.stream().map(this::convertToResponseDTO).toList();
    }

    /**
     * Delete/mark notification as inactive.
     *
     * @param notificationId the ID of the notification to delete
     * @throws ResourceNotFoundException if notification not found
     */
    public void deleteNotification(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with ID: " + notificationId));

        notification.setActive(false);
        notificationRepository.save(notification);
    }

    /**
     * Delete all notifications for a user (soft delete).
     *
     * @param userId the ID of the user
     * @return the count of deleted notifications
     */
    public long deleteAllUserNotifications(Long userId) {
        List<Notification> notifications = notificationRepository
                .findByRecipientIdAndActive(userId, true,
                        org.springframework.data.domain.PageRequest.of(0, Integer.MAX_VALUE))
                .getContent();

        for (Notification notification : notifications) {
            notification.setActive(false);
        }

        notificationRepository.saveAll(notifications);
        return notifications.size();
    }

    /**
     * Helper method to send notification when volunteer joins event.
     *
     * @param eventId     the ID of the event
     * @param volunteerId the ID of the volunteer joining
     * @param event       the event entity
     * @param volunteer   the volunteer entity
     */
    public void notifyVolunteerJoined(Long eventId, Long volunteerId, Event event, User volunteer) {
        String message = volunteer.getFirstName() + " " + volunteer.getLastName() + " has joined the event "
                + event.getTitle();
        createNotification(event.getOrganizer().getId(), NotificationType.VOLUNTEER_JOINED, message, event, volunteer);
    }

    /**
     * Helper method to send notification when volunteer cancels event.
     *
     * @param eventId     the ID of the event
     * @param volunteerId the ID of the volunteer canceling
     * @param event       the event entity
     * @param volunteer   the volunteer entity
     */
    public void notifyVolunteerCancelled(Long eventId, Long volunteerId, Event event, User volunteer) {
        String message = volunteer.getFirstName() + " " + volunteer.getLastName()
                + " has cancelled participation in event " + event.getTitle();
        createNotification(event.getOrganizer().getId(), NotificationType.VOLUNTEER_CANCELLED, message, event,
                volunteer);
    }

    /**
     * Convert Notification entity to NotificationResponseDTO.
     *
     * @param notification the notification entity
     * @return the notification as NotificationResponseDTO
     */
    private NotificationResponseDTO convertToResponseDTO(Notification notification) {
        NotificationResponseDTO dto = new NotificationResponseDTO();
        dto.setId(notification.getId());
        dto.setType(notification.getType().name());
        dto.setMessage(notification.getMessage());

        if (notification.getRelatedEvent() != null) {
            dto.setRelatedEventId(notification.getRelatedEvent().getId());
            dto.setRelatedEventTitle(notification.getRelatedEvent().getTitle());
        }

        if (notification.getTriggeredByUser() != null) {
            dto.setTriggeredByUserId(notification.getTriggeredByUser().getId());
            dto.setTriggeredByUserName(notification.getTriggeredByUser().getFirstName() + " "
                    + notification.getTriggeredByUser().getLastName());
        }

        dto.setIsRead(notification.getIsRead());
        dto.setReadAt(notification.getReadAt());
        dto.setCreatedAt(notification.getCreatedAt());

        return dto;
    }

}
