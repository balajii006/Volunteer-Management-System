package com.volunteerhub.services;

import com.volunteerhub.dtos.CreateEventDTO;
import com.volunteerhub.dtos.EventResponseDTO;
import com.volunteerhub.dtos.UpdateEventDTO;
import com.volunteerhub.entities.Event;
import com.volunteerhub.entities.EventStatus;
import com.volunteerhub.entities.User;
import com.volunteerhub.exceptions.ResourceNotFoundException;
import com.volunteerhub.exceptions.UnauthorizedException;
import com.volunteerhub.repositories.EventRepository;
import com.volunteerhub.repositories.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EventService {

    private final EventRepository eventRepository;
    private final UserRepository userRepository;

    public EventService(EventRepository eventRepository, UserRepository userRepository) {
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
    }

    /**
     * Create a new event. Only organizers can create events.
     *
     * @param createEventDTO the event creation data
     * @param organizerId    the ID of the organizer creating the event
     * @return the created event as EventResponseDTO
     * @throws ResourceNotFoundException if organizer not found
     */
    public EventResponseDTO createEvent(CreateEventDTO createEventDTO, Long organizerId) {
        User organizer = userRepository.findById(organizerId)
                .orElseThrow(() -> new ResourceNotFoundException("Organizer not found with ID: " + organizerId));

        Event event = new Event();
        event.setTitle(createEventDTO.getTitle());
        event.setDescription(createEventDTO.getDescription());
        event.setLocation(createEventDTO.getLocation());
        event.setEventDate(createEventDTO.getEventDate());
        event.setStartTime(createEventDTO.getStartTime());
        event.setEndTime(createEventDTO.getEndTime());
        event.setMaxVolunteers(createEventDTO.getMaxVolunteers() != null ? createEventDTO.getMaxVolunteers() : 0);
        event.setCurrentVolunteers(0);
        event.setStatus(EventStatus.SCHEDULED);
        event.setOrganizer(organizer);
        event.setActive(true);

        Event savedEvent = eventRepository.save(event);
        return convertToResponseDTO(savedEvent);
    }

    /**
     * Update an existing event. Only the organizer can update their event.
     *
     * @param eventId        the ID of the event to update
     * @param updateEventDTO the updated event data
     * @param userId         the ID of the user attempting the update
     * @return the updated event as EventResponseDTO
     * @throws ResourceNotFoundException if event or user not found
     * @throws UnauthorizedException     if user is not the event organizer
     */
    public EventResponseDTO updateEvent(Long eventId, UpdateEventDTO updateEventDTO, Long userId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Authorization check: only organizer can update their event
        if (!event.getOrganizer().getId().equals(userId)) {
            throw new UnauthorizedException(
                    "You are not authorized to update this event. Only the organizer can modify events.");
        }

        event.setTitle(updateEventDTO.getTitle());
        event.setDescription(updateEventDTO.getDescription());
        event.setLocation(updateEventDTO.getLocation());
        event.setEventDate(updateEventDTO.getEventDate());
        event.setStartTime(updateEventDTO.getStartTime());
        event.setEndTime(updateEventDTO.getEndTime());
        event.setMaxVolunteers(updateEventDTO.getMaxVolunteers() != null ? updateEventDTO.getMaxVolunteers() : 0);

        if (updateEventDTO.getStatus() != null) {
            try {
                event.setStatus(EventStatus.valueOf(updateEventDTO.getStatus().toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid event status: " + updateEventDTO.getStatus());
            }
        }

        Event updatedEvent = eventRepository.save(event);
        return convertToResponseDTO(updatedEvent);
    }

    /**
     * Delete an event. Only the organizer can delete their event.
     *
     * @param eventId the ID of the event to delete
     * @param userId  the ID of the user attempting the deletion
     * @throws ResourceNotFoundException if event not found
     * @throws UnauthorizedException     if user is not the event organizer
     */
    public void deleteEvent(Long eventId, Long userId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Authorization check: only organizer can delete their event
        if (!event.getOrganizer().getId().equals(userId)) {
            throw new UnauthorizedException(
                    "You are not authorized to delete this event. Only the organizer can delete events.");
        }

        event.setActive(false);
        eventRepository.save(event);
    }

    /**
     * Get a specific event by ID.
     *
     * @param eventId the ID of the event to retrieve
     * @return the event as EventResponseDTO
     * @throws ResourceNotFoundException if event not found
     */
    @Transactional(readOnly = true)
    public EventResponseDTO getEventById(Long eventId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));
        return convertToResponseDTO(event);
    }

    /**
     * Get all active events with pagination.
     *
     * @param pageable pagination information
     * @return a page of active events
     */
    @Transactional(readOnly = true)
    public Page<EventResponseDTO> getAllEvents(Pageable pageable) {
        Page<Event> events = eventRepository.findByActive(true, pageable);
        return events.map(this::convertToResponseDTO);
    }

    /**
     * Get all events by a specific organizer with pagination.
     *
     * @param organizerId the ID of the organizer
     * @param pageable    pagination information
     * @return a page of events organized by the specified organizer
     * @throws ResourceNotFoundException if organizer not found
     */
    @Transactional(readOnly = true)
    public Page<EventResponseDTO> getEventsByOrganizer(Long organizerId, Pageable pageable) {
        // Verify organizer exists
        if (!userRepository.existsById(organizerId)) {
            throw new ResourceNotFoundException("Organizer not found with ID: " + organizerId);
        }

        Page<Event> events = eventRepository.findByOrganizerId(organizerId, pageable);
        return events.map(this::convertToResponseDTO);
    }

    /**
     * Get all events by status with pagination.
     *
     * @param status   the event status to filter by
     * @param pageable pagination information
     * @return a page of events with the specified status
     */
    @Transactional(readOnly = true)
    public Page<EventResponseDTO> getEventsByStatus(EventStatus status, Pageable pageable) {
        Page<Event> events = eventRepository.findByStatus(status, pageable);
        return events.map(this::convertToResponseDTO);
    }

    /**
     * Get events with available volunteer spots.
     *
     * @param pageable pagination information
     * @return a page of events that still have available spots
     */
    @Transactional(readOnly = true)
    public Page<EventResponseDTO> getEventsWithAvailableSpots(Pageable pageable) {
        Page<Event> events = eventRepository.findEventsByAvailableSpots(EventStatus.SCHEDULED, pageable);
        return events.map(this::convertToResponseDTO);
    }

    /**
     * Update the current volunteer count for an event.
     *
     * @param eventId   the ID of the event
     * @param increment the amount to increment or decrement
     * @return the updated volunteer count
     * @throws ResourceNotFoundException if event not found
     */
    public Integer updateVolunteerCount(Long eventId, Integer increment) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        int newCount = event.getCurrentVolunteers() + increment;
        if (newCount < 0) {
            newCount = 0;
        }
        if (event.getMaxVolunteers() != null && newCount > event.getMaxVolunteers()) {
            throw new IllegalArgumentException("Cannot exceed maximum volunteers for this event.");
        }

        event.setCurrentVolunteers(newCount);
        eventRepository.save(event);
        return newCount;
    }

    /**
     * Update event status.
     *
     * @param eventId the ID of the event
     * @param status  the new status
     * @param userId  the ID of the user attempting the status change
     * @return the updated event as EventResponseDTO
     * @throws ResourceNotFoundException if event not found
     * @throws UnauthorizedException     if user is not the event organizer
     */
    public EventResponseDTO updateEventStatus(Long eventId, EventStatus status, Long userId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Authorization check: only organizer can change event status
        if (!event.getOrganizer().getId().equals(userId)) {
            throw new UnauthorizedException(
                    "You are not authorized to change this event's status. Only the organizer can modify events.");
        }

        event.setStatus(status);
        Event updatedEvent = eventRepository.save(event);
        return convertToResponseDTO(updatedEvent);
    }

    /**
     * Convert Event entity to EventResponseDTO.
     *
     * @param event the event entity
     * @return the event as EventResponseDTO
     */
    private EventResponseDTO convertToResponseDTO(Event event) {
        EventResponseDTO dto = new EventResponseDTO();
        dto.setId(event.getId());
        dto.setTitle(event.getTitle());
        dto.setDescription(event.getDescription());
        dto.setLocation(event.getLocation());
        dto.setEventDate(event.getEventDate());
        dto.setStartTime(event.getStartTime());
        dto.setEndTime(event.getEndTime());
        dto.setMaxVolunteers(event.getMaxVolunteers());
        dto.setCurrentVolunteers(event.getCurrentVolunteers());
        dto.setStatus(event.getStatus().name());
        dto.setOrganizerName(event.getOrganizer().getFirstName() + " " + event.getOrganizer().getLastName());
        dto.setOrganizerId(event.getOrganizer().getId());
        dto.setCreatedAt(event.getCreatedAt());
        dto.setUpdatedAt(event.getUpdatedAt());
        dto.setActive(event.getActive());
        return dto;
    }

}
