package com.volunteerhub.services;

import com.volunteerhub.dtos.AuthResponseDTO;
import com.volunteerhub.dtos.LoginDTO;
import com.volunteerhub.dtos.RegisterDTO;
import com.volunteerhub.entities.Role;
import com.volunteerhub.entities.User;
import com.volunteerhub.exceptions.InvalidCredentialsException;
import com.volunteerhub.exceptions.DuplicateResourceException;
import com.volunteerhub.repositories.UserRepository;
import com.volunteerhub.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
@Transactional
public class AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public AuthResponseDTO login(LoginDTO loginDTO) {
        try {
            // Find user by email
            User user = userRepository.findByEmail(loginDTO.getEmail())
                    .orElseThrow(() -> new InvalidCredentialsException("Invalid email or password"));

            // Authenticate using username (Spring Security internally uses username)
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            user.getUsername(),
                            loginDTO.getPassword()));

            // Generate JWT token
            String token = jwtUtil.generateToken(
                    (org.springframework.security.core.userdetails.UserDetails) authentication.getPrincipal());

            Set<String> roles = new HashSet<>();
            roles.add(user.getRole().toString());

            return new AuthResponseDTO(
                    token,
                    user.getId(),
                    user.getUsername(),
                    user.getEmail(),
                    roles);
        } catch (AuthenticationException e) {
            throw new InvalidCredentialsException("Invalid email or password");
        }
    }

    public AuthResponseDTO register(RegisterDTO registerDTO) {
        // Validate password match
        if (!registerDTO.getPassword().equals(registerDTO.getConfirmPassword())) {
            throw new InvalidCredentialsException("Passwords do not match");
        }

        // Check if username exists
        if (userRepository.existsByUsername(registerDTO.getUsername())) {
            throw new DuplicateResourceException("Username already exists");
        }

        // Check if email exists
        if (userRepository.existsByEmail(registerDTO.getEmail())) {
            throw new DuplicateResourceException("Email already exists");
        }

        // Determine role
        Role role;
        try {
            role = Role.valueOf("ROLE_" + registerDTO.getRole().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidCredentialsException("Invalid role: " + registerDTO.getRole());
        }

        // Create new user
        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setEmail(registerDTO.getEmail());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setFirstName(registerDTO.getFirstName());
        user.setLastName(registerDTO.getLastName());
        user.setRole(role);
        user.setActive(true);

        User savedUser = userRepository.save(user);

        // Generate token
        Collection<GrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(savedUser.getRole().toString()));
        String token = jwtUtil.generateToken(savedUser.getUsername(), authorities);

        Set<String> roles = new HashSet<>();
        roles.add(savedUser.getRole().toString());

        return new AuthResponseDTO(
                token,
                "Bearer",
                savedUser.getId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getFirstName(),
                savedUser.getLastName(),
                roles,
                savedUser.getActive());
    }

}
