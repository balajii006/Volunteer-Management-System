package com.volunteerhub.services;

import com.volunteerhub.dtos.ParticipationResponseDTO;
import com.volunteerhub.entities.Event;
import com.volunteerhub.entities.Participation;
import com.volunteerhub.entities.ParticipationStatus;
import com.volunteerhub.entities.User;
import com.volunteerhub.exceptions.DuplicateResourceException;
import com.volunteerhub.exceptions.ResourceNotFoundException;
import com.volunteerhub.exceptions.UnauthorizedException;
import com.volunteerhub.repositories.EventRepository;
import com.volunteerhub.repositories.ParticipationRepository;
import com.volunteerhub.repositories.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional
public class ParticipationService {

    private final ParticipationRepository participationRepository;
    private final EventRepository eventRepository;
    private final UserRepository userRepository;
    private final EventService eventService;
    private final NotificationService notificationService;

    public ParticipationService(ParticipationRepository participationRepository,
            EventRepository eventRepository,
            UserRepository userRepository,
            EventService eventService,
            NotificationService notificationService) {
        this.participationRepository = participationRepository;
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
        this.eventService = eventService;
        this.notificationService = notificationService;
    }

    /**
     * Join an event as a volunteer.
     *
     * @param eventId     the ID of the event to join
     * @param volunteerId the ID of the volunteer joining
     * @return the participation record created
     * @throws ResourceNotFoundException  if event or volunteer not found
     * @throws DuplicateResourceException if volunteer already joined this event
     * @throws IllegalArgumentException   if event has no available spots
     */
    public ParticipationResponseDTO joinEvent(Long eventId, Long volunteerId) {
        // Verify event exists
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Verify volunteer exists
        User volunteer = userRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException("Volunteer not found with ID: " + volunteerId));

        // Prevent duplicate joining
        boolean alreadyParticipating = participationRepository.existsByEventIdAndVolunteerIdAndActive(eventId,
                volunteerId, true);
        if (alreadyParticipating) {
            throw new DuplicateResourceException("Volunteer has already joined this event.");
        }

        // Check capacity
        if (event.getMaxVolunteers() != null && event.getMaxVolunteers() > 0) {
            if (event.getCurrentVolunteers() >= event.getMaxVolunteers()) {
                throw new IllegalArgumentException("Event has reached maximum volunteer capacity.");
            }
        }

        // Create participation record
        Participation participation = new Participation(volunteer, event, ParticipationStatus.JOINED);
        participation.setJoinedAt(LocalDateTime.now());

        Participation savedParticipation = participationRepository.save(participation);

        // Increment event volunteer count
        eventService.updateVolunteerCount(eventId, 1);

        // Send notification to event organizer
        notificationService.notifyVolunteerJoined(eventId, volunteerId, event, volunteer);

        return convertToResponseDTO(savedParticipation);
    }

    /**
     * Cancel a volunteer's participation in an event.
     *
     * @param eventId     the ID of the event
     * @param volunteerId the ID of the volunteer canceling
     * @throws ResourceNotFoundException if participation record not found
     */
    public void cancelParticipation(Long eventId, Long volunteerId) {
        Participation participation = participationRepository.findByVolunteerAndEvent(volunteerId, eventId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Participation record not found for volunteer " + volunteerId + " in event " + eventId));

        participation.setStatus(ParticipationStatus.CANCELLED);
        participation.setCancelledAt(LocalDateTime.now());
        participation.setActive(false);

        participationRepository.save(participation);

        // Decrement event volunteer count
        eventService.updateVolunteerCount(eventId, -1);

        // Send notification to event organizer
        Event event = participation.getEvent();
        User volunteer = participation.getVolunteer();
        notificationService.notifyVolunteerCancelled(eventId, volunteerId, event, volunteer);
    }

    /**
     * Get all active participants of an event. Only organizer of the event can
     * view.
     *
     * @param eventId     the ID of the event
     * @param organizerId the ID of the requesting user (must be the organizer)
     * @param pageable    pagination information
     * @return a page of participants
     * @throws ResourceNotFoundException if event not found
     * @throws UnauthorizedException     if requester is not the event organizer
     */
    @Transactional(readOnly = true)
    public Page<ParticipationResponseDTO> getEventParticipants(Long eventId, Long organizerId, Pageable pageable) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with ID: " + eventId));

        // Authorization check: only organizer can view participants
        if (!event.getOrganizer().getId().equals(organizerId)) {
            throw new UnauthorizedException(
                    "You are not authorized to view participants of this event. Only the organizer can view event participants.");
        }

        Page<Participation> participations = participationRepository.findActiveParticipationsByEventOrdered(eventId,
                pageable);
        return participations.map(this::convertToResponseDTO);
    }

    /**
     * Get all events a volunteer has joined.
     *
     * @param volunteerId the ID of the volunteer
     * @param pageable    pagination information
     * @return a page of participation records
     */
    @Transactional(readOnly = true)
    public Page<ParticipationResponseDTO> getVolunteerParticipations(Long volunteerId, Pageable pageable) {
        Page<Participation> participations = participationRepository.findByVolunteerIdAndActive(volunteerId, true,
                pageable);
        return participations.map(this::convertToResponseDTO);
    }

    /**
     * Check if a volunteer is participating in an event.
     *
     * @param eventId     the ID of the event
     * @param volunteerId the ID of the volunteer
     * @return true if the volunteer is actively participating, false otherwise
     */
    @Transactional(readOnly = true)
    public boolean isVolunteerParticipating(Long eventId, Long volunteerId) {
        return participationRepository.existsByEventIdAndVolunteerIdAndActive(eventId, volunteerId, true);
    }

    /**
     * Get participation record details.
     *
     * @param participationId the ID of the participation record
     * @return the participation details
     * @throws ResourceNotFoundException if participation not found
     */
    @Transactional(readOnly = true)
    public ParticipationResponseDTO getParticipationById(Long participationId) {
        Participation participation = participationRepository.findById(participationId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Participation record not found with ID: " + participationId));
        return convertToResponseDTO(participation);
    }

    /**
     * Get count of active participants for an event.
     *
     * @param eventId the ID of the event
     * @return the number of active participants
     */
    @Transactional(readOnly = true)
    public long getParticipantCount(Long eventId) {
        return participationRepository.countByEventIdAndActive(eventId, true);
    }

    /**
     * Convert Participation entity to ParticipationResponseDTO.
     *
     * @param participation the participation entity
     * @return the participation as ParticipationResponseDTO
     */
    private ParticipationResponseDTO convertToResponseDTO(Participation participation) {
        ParticipationResponseDTO dto = new ParticipationResponseDTO();
        dto.setId(participation.getId());
        dto.setVolunteerId(participation.getVolunteer().getId());
        dto.setVolunteerName(
                participation.getVolunteer().getFirstName() + " " + participation.getVolunteer().getLastName());
        dto.setEventId(participation.getEvent().getId());
        dto.setEventTitle(participation.getEvent().getTitle());
        dto.setStatus(participation.getStatus().name());
        dto.setJoinedAt(participation.getJoinedAt());
        dto.setCancelledAt(participation.getCancelledAt());
        dto.setActive(participation.getActive());
        return dto;
    }

}
