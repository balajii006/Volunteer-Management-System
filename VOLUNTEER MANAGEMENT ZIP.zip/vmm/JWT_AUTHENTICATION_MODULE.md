# VolunteerHub - JWT Authentication Module Documentation

## Overview

Complete JWT-based authentication module with role-based access control (RBAC) for VolunteerHub. Built with Spring Security, no Lombok, and manual getters/setters.

## Authentication Flow

### 1. Registration
```
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_volunteer",
  "email": "john@example.com",
  "password": "SecurePassword123",
  "confirmPassword": "SecurePassword123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "VOLUNTEER"
}

Response (201 Created):
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "userId": 1,
  "username": "john_volunteer",
  "email": "john@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "roles": ["ROLE_VOLUNTEER"],
  "active": true
}
```

### 2. Login
```
POST /api/auth/login
Content-Type: application/json

{
  "username": "john_volunteer",
  "password": "SecurePassword123"
}

Response (200 OK):
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "userId": 1,
  "username": "john_volunteer",
  "email": "john@example.com",
  "roles": ["ROLE_VOLUNTEER"]
}
```

### 3. Authenticated Request
```
GET /api/users
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## Key Components

### 1. **Role Enum** (`Role.java`)
Defines two roles:
- `ROLE_VOLUNTEER`: Regular volunteer user
- `ROLE_ORGANIZER`: Administrator with full access

```java
public enum Role {
    ROLE_VOLUNTEER("Volunteer"),
    ROLE_ORGANIZER("Organizer");
}
```

### 2. **User Entity** (`User.java`)
- Includes `Role` enum field
- Tracks creation/update timestamps via `BaseEntity`
- Manual constructors and getters/setters (no Lombok)
- BCrypt password encryption

```java
@Entity
public class User extends BaseEntity {
    private String username;
    private String email;
    private String password;
    private Role role;
    private Boolean active;
    // ... getters/setters
}
```

### 3. **JWT Utility** (`JwtUtil.java`)
Handles JWT token generation and validation:
- **generateToken()** - Creates JWT with username and roles
- **extractUsername()** - Extracts username from token
- **extractRoles()** - Extracts roles claim
- **isTokenValid()** - Validates signature and expiration
- **isTokenExpired()** - Checks token expiration

```java
@Component
public class JwtUtil {
    public String generateToken(UserDetails userDetails);
    public String generateToken(String username, Collection<? extends GrantedAuthority> authorities);
    public boolean isTokenValid(String token);
    public String extractUsername(String token);
    public String extractRoles(String token);
}
```

### 4. **JWT Filter** (`JwtAuthenticationFilter.java`)
- Intercepts requests and extracts JWT from Authorization header
- Validates token and sets authentication in security context
- Extracts roles from token claims
- Converts roles to Spring Security `GrantedAuthority`

### 5. **Auth Service** (`AuthService.java`)
Handles authentication business logic:
- **login()** - Authenticates credentials and generates JWT
- **register()** - Creates new user with specified role

Features:
- Password confirmation validation
- Duplicate username/email detection
- Role-based registration
- Return user details with roles

### 6. **Custom User Details Service** (`CustomUserDetailsService.java`)
Implements Spring's `UserDetailsService`:
- Loads user by username
- Loads user by ID
- Converts User entity to Spring `UserDetails`
- Maps User role to Spring `GrantedAuthority`

### 7. **Security Configuration** (`SecurityConfig.java`)
Configures Spring Security:

```java
- CSRF disabled
- Stateless session management (JWT)
- Public endpoints: /auth/register, /auth/login
- Role-based authorization:
  * GET /users → VOLUNTEER or ORGANIZER
  * POST /users → ORGANIZER only
  * PUT /users → ORGANIZER only
  * DELETE /users → ORGANIZER only
- JWT filter added before UsernamePasswordAuthenticationFilter
```

### 8. **DTOs**

#### RegisterDTO
```java
{
  "username": "string",      // Required, 3-50 chars
  "email": "string",         // Required, valid email
  "password": "string",      // Required, min 6 chars
  "confirmPassword": "string", // Required, must match password
  "firstName": "string",     // Optional
  "lastName": "string",      // Optional
  "role": "VOLUNTEER|ORGANIZER" // Required
}
```

#### LoginDTO
```java
{
  "username": "string",  // Required
  "password": "string"   // Required
}
```

#### AuthResponseDTO
```java
{
  "token": "string",
  "type": "Bearer",
  "userId": "long",
  "username": "string",
  "email": "string",
  "firstName": "string",
  "lastName": "string",
  "roles": ["ROLE_VOLUNTEER", "..."],
  "active": "boolean"
}
```

## Password Encryption

Uses **BCrypt** via Spring Security:
```java
@Bean
public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
}
```

- Passwords are hashed with BCryptPasswordEncoder
- Strength level: 10 (default)
- Each password is salted uniquely

## JWT Configuration

In `application.yml`:
```yaml
jwt:
  secret: volunteerhubsecretkeythatisatleast32characterslong
  expiration: 86400000  # 24 hours in milliseconds
```

⚠️ **Important**: Change the secret key in production!

## Error Handling

Custom exceptions handled globally:

| Exception | HTTP Status | Description |
|-----------|------------|-------------|
| `ResourceNotFoundException` | 404 | Resource not found |
| `DuplicateResourceException` | 409 | Username/Email already exists |
| `InvalidCredentialsException` | 401 | Invalid username/password |
| `UnauthorizedException` | 401 | Unauthorized access |
| `MethodArgumentNotValidException` | 400 | Validation failed |

Example error response:
```json
{
  "timestamp": "2024-02-14T10:30:00",
  "status": 401,
  "message": "Invalid username or password",
  "path": "uri=/api/auth/login"
}
```

## Security Best Practices

✅ Implemented:
- No Lombok (full transparency)
- Manual password encoding with BCrypt
- JWT stored in Authorization header (Bearer scheme)
- Stateless authentication (no sessions)
- CSRF disabled (stateless API)
- Role-based endpoint protection
- Input validation on all DTOs
- Automatic token expiration

⚠️ Recommendations for Production:
- Use strong JWT secret (min 32 characters, alphanumeric + special chars)
- Store secret in environment variables, not in code
- Use HTTPS/TLS for all endpoints
- Implement token refresh mechanism
- Add rate limiting on auth endpoints
- Monitor failed login attempts
- Use shorter token expiration (30 min - 1 hour)
- Implement logout/token blacklist mechanism

## API Endpoints

### Public Endpoints
```
POST   /api/auth/register     - Register new user
POST   /api/auth/login        - Login and get JWT
```

### Protected Endpoints (VOLUNTEER + ORGANIZER)
```
GET    /api/users             - List all users (both roles can read)
GET    /api/users/{id}        - Get user by ID
GET    /api/users/username/{username} - Get user by username
```

### Protected Endpoints (ORGANIZER only)
```
POST   /api/users             - Create new user
PUT    /api/users/{id}        - Update user
DELETE /api/users/{id}        - Delete user
```

## Testing

### Register a Volunteer
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "volunteer1",
    "email": "vol1@example.com",
    "password": "Pass123!",
    "confirmPassword": "Pass123!",
    "firstName": "Alice",
    "lastName": "Smith",
    "role": "VOLUNTEER"
  }'
```

### Register an Organizer
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "organizer1",
    "email": "org1@example.com",
    "password": "Pass123!",
    "confirmPassword": "Pass123!",
    "firstName": "Bob",
    "lastName": "Johnson",
    "role": "ORGANIZER"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "volunteer1",
    "password": "Pass123!"
  }'
```

### Access Protected Resource
```bash
curl -X GET http://localhost:8080/api/users/1 \
  -H "Authorization: Bearer <your_jwt_token>"
```

## File Structure

```
src/main/java/com/volunteerhub/
├── controllers/
│   └── AuthController.java
├── services/
│   ├── AuthService.java
│   └── UserService.java
├── repositories/
│   └── UserRepository.java
├── entities/
│   ├── User.java
│   ├── Role.java
│   └── BaseEntity.java
├── security/
│   ├── JwtUtil.java
│   ├── JwtAuthenticationFilter.java
│   └── JwtConstants.java
├── dtos/
│   ├── RegisterDTO.java
│   ├── LoginDTO.java
│   ├── AuthResponseDTO.java
│   └── UserDTO.java
├── config/
│   ├── SecurityConfig.java
│   ├── CustomUserDetailsService.java
│   └── GlobalExceptionHandler.java
└── exceptions/
    ├── InvalidCredentialsException.java
    ├── DuplicateResourceException.java
    ├── ResourceNotFoundException.java
    └── UnauthorizedException.java
```

## Performance Considerations

- JWT validation caches public key
- Stateless authentication eliminates session lookups
- Database queries only on first authentication
- BCrypt configured with standard strength (10)

## Future Enhancements

- [ ] Refresh token implementation
- [ ] Multi-factor authentication (MFA)
- [ ] OAuth2 integration
- [ ] Social login (Google, GitHub)
- [ ] Token blacklist for logout
- [ ] Rate limiting module
- [ ] Audit logging
- [ ] Remember-me functionality

