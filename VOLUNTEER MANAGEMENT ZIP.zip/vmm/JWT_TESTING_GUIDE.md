# VolunteerHub - JWT Authentication Testing Guide

## API Testing & Examples

Complete guide with `curl` commands for testing the JWT authentication module.

---

## 1. Register a Volunteer

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice_volunteer",
    "email": "alice@volunteerhub.com",
    "password": "SecurePassword123",
    "confirmPassword": "SecurePassword123",
    "firstName": "Alice",
    "lastName": "Smith",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (201 Created)
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhbGljZV92b2x1bnRlZXIiLCJyb2xlcyI6IlJPTEVfVk9MVVVOVEVFUiIsImlhdCI6MTcwNzg5MjIwMCwiZXhwIjoxNzA3OTc4NjAwfQ.abc123...",
  "type": "Bearer",
  "userId": 1,
  "username": "alice_volunteer",
  "email": "alice@volunteerhub.com",
  "firstName": "Alice",
  "lastName": "Smith",
  "roles": [
    "ROLE_VOLUNTEER"
  ],
  "active": true
}
```

---

## 2. Register an Organizer

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "bob_organizer",
    "email": "bob@volunteerhub.com",
    "password": "SecurePassword456",
    "confirmPassword": "SecurePassword456",
    "firstName": "Bob",
    "lastName": "Johnson",
    "role": "ORGANIZER"
  }' | json_pp
```

### Response (201 Created)
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJib2Jfb3JnYW5pemVyIiwicm9sZXMiOiJST0xFX09SR0FOSVpFUiIsImlhdCI6MTcwNzg5MjMwMCwiZXhwIjoxNzA3OTc4NzAwfQ.def456...",
  "type": "Bearer",
  "userId": 2,
  "username": "bob_organizer",
  "email": "bob@volunteerhub.com",
  "firstName": "Bob",
  "lastName": "Johnson",
  "roles": [
    "ROLE_ORGANIZER"
  ],
  "active": true
}
```

---

## 3. Login as Volunteer

### Request
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice_volunteer",
    "password": "SecurePassword123"
  }' | json_pp
```

### Response (200 OK)
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhbGljZV92b2x1bnRlZXIiLCJyb2xlcyI6IlJPTEVfVk9MVVVOVEVFUiIsImlhdCI6MTcwNzg5MjQwMCwiZXhwIjoxNzA3OTc4ODAwfQ.xyz789...",
  "type": "Bearer",
  "userId": 1,
  "username": "alice_volunteer",
  "email": "alice@volunteerhub.com",
  "roles": [
    "ROLE_VOLUNTEER"
  ]
}
```

### Store Token (for use in subsequent requests)
```bash
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhbGljZV92b2x1bnRlZXIiLCJyb2xlcyI6IlJPTEVfVk9MVVVOVEVFUiIsImlhdCI6MTcwNzg5MjQwMCwiZXhwIjoxNzA3OTc4ODAwfQ.xyz789..."
```

---

## 4. Get All Users (As Volunteer)

### Request
```bash
TOKEN="your_jwt_token_here"

curl -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer $TOKEN" | json_pp
```

### Response (200 OK)
```json
[
  {
    "id": 1,
    "username": "alice_volunteer",
    "email": "alice@volunteerhub.com",
    "firstName": "Alice",
    "lastName": "Smith",
    "roles": [
      "ROLE_VOLUNTEER"
    ],
    "active": true
  },
  {
    "id": 2,
    "username": "bob_organizer",
    "email": "bob@volunteerhub.com",
    "firstName": "Bob",
    "lastName": "Johnson",
    "roles": [
      "ROLE_ORGANIZER"
    ],
    "active": true
  }
]
```

---

## 5. Get User by ID (As Volunteer)

### Request
```bash
TOKEN="your_jwt_token_here"

curl -X GET http://localhost:8080/api/users/1 \
  -H "Authorization: Bearer $TOKEN" | json_pp
```

### Response (200 OK)
```json
{
  "id": 1,
  "username": "alice_volunteer",
  "email": "alice@volunteerhub.com",
  "firstName": "Alice",
  "lastName": "Smith",
  "roles": [
    "ROLE_VOLUNTEER"
  ],
  "active": true
}
```

---

## 6. Get User by Username

### Request
```bash
TOKEN="your_jwt_token_here"

curl -X GET http://localhost:8080/api/users/username/alice_volunteer \
  -H "Authorization: Bearer $TOKEN" | json_pp
```

### Response (200 OK)
```json
{
  "id": 1,
  "username": "alice_volunteer",
  "email": "alice@volunteerhub.com",
  "firstName": "Alice",
  "lastName": "Smith",
  "roles": [
    "ROLE_VOLUNTEER"
  ],
  "active": true
}
```

---

## 7. Create User (Organizer Only)

### Request (Success - Organizer Token)
```bash
ORG_TOKEN="your_organizer_jwt_token_here"

curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ORG_TOKEN" \
  -d '{
    "username": "charlie_volunteer",
    "email": "charlie@volunteerhub.com",
    "password": "SecurePassword789",
    "firstName": "Charlie",
    "lastName": "Brown",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (201 Created)
```json
{
  "id": 3,
  "username": "charlie_volunteer",
  "email": "charlie@volunteerhub.com",
  "firstName": "Charlie",
  "lastName": "Brown",
  "roles": [
    "ROLE_VOLUNTEER"
  ],
  "active": true
}
```

### Request (Failure - Volunteer Token)
```bash
VOL_TOKEN="your_volunteer_jwt_token_here"

curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $VOL_TOKEN" \
  -d '{
    "username": "david_user",
    "email": "david@volunteerhub.com",
    "password": "Pass123!",
    "firstName": "David",
    "lastName": "Lee",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (403 Forbidden)
```json
{
  "timestamp": "2024-02-14T12:34:56.789Z",
  "status": 403,
  "message": "Access Denied",
  "path": "uri=/api/users"
}
```

---

## 8. Update User (Organizer Only)

### Request
```bash
ORG_TOKEN="your_organizer_jwt_token_here"

curl -X PUT http://localhost:8080/api/users/1 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ORG_TOKEN" \
  -d '{
    "firstName": "Alicia",
    "lastName": "Smith-Johnson",
    "email": "alicia.new@volunteerhub.com"
  }' | json_pp
```

### Response (200 OK)
```json
{
  "id": 1,
  "username": "alice_volunteer",
  "email": "alicia.new@volunteerhub.com",
  "firstName": "Alicia",
  "lastName": "Smith-Johnson",
  "roles": [
    "ROLE_VOLUNTEER"
  ],
  "active": true
}
```

---

## 9. Delete User (Organizer Only)

### Request
```bash
ORG_TOKEN="your_organizer_jwt_token_here"

curl -X DELETE http://localhost:8080/api/users/3 \
  -H "Authorization: Bearer $ORG_TOKEN" \
  -v
```

### Response (204 No Content)
```
< HTTP/1.1 204 No Content
```

---

## Error Scenarios

### 10. Invalid Credentials on Login

### Request
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice_volunteer",
    "password": "WrongPassword123"
  }' | json_pp
```

### Response (401 Unauthorized)
```json
{
  "timestamp": "2024-02-14T12:35:00Z",
  "status": 401,
  "message": "Invalid username or password",
  "path": "uri=/api/auth/login"
}
```

---

### 11. Duplicate Username on Registration

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice_volunteer",
    "email": "different@example.com",
    "password": "SecurePassword123",
    "confirmPassword": "SecurePassword123",
    "firstName": "Alice2",
    "lastName": "Smith2",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (409 Conflict)
```json
{
  "timestamp": "2024-02-14T12:35:15Z",
  "status": 409,
  "message": "Username already exists",
  "path": "uri=/api/auth/register"
}
```

---

### 12. Duplicate Email on Registration

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "new_user",
    "email": "alice@volunteerhub.com",
    "password": "SecurePassword123",
    "confirmPassword": "SecurePassword123",
    "firstName": "New",
    "lastName": "User",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (409 Conflict)
```json
{
  "timestamp": "2024-02-14T12:35:30Z",
  "status": 409,
  "message": "Email already exists",
  "path": "uri=/api/auth/register"
}
```

---

### 13. Mismatched Passwords on Registration

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "new_user",
    "email": "new@example.com",
    "password": "SecurePassword123",
    "confirmPassword": "DifferentPassword456",
    "firstName": "New",
    "lastName": "User",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (401 Unauthorized)
```json
{
  "timestamp": "2024-02-14T12:35:45Z",
  "status": 401,
  "message": "Passwords do not match",
  "path": "uri=/api/auth/register"
}
```

---

### 14. Invalid Validation on Registration

### Request
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "ab",
    "email": "invalid-email",
    "password": "123",
    "confirmPassword": "123",
    "role": "VOLUNTEER"
  }' | json_pp
```

### Response (400 Bad Request)
```json
{
  "timestamp": "2024-02-14T12:36:00Z",
  "status": 400,
  "message": "Validation failed",
  "errors": {
    "username": "Username must be between 3 and 50 characters",
    "email": "Email should be valid",
    "password": "Password must be at least 6 characters"
  },
  "path": "uri=/api/auth/register"
}
```

---

### 15. Missing Authentication Token

### Request
```bash
curl -X GET http://localhost:8080/api/users
```

### Response (401 Unauthorized)
```
< HTTP/1.1 401 Unauthorized
< WWW-Authenticate: Bearer error="unauthorized"
```

---

### 16. Invalid/Expired Token

### Request
```bash
curl -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer invalid.token.here"
```

### Response (401 Unauthorized)
```
< HTTP/1.1 401 Unauthorized
```

---

### 17. Resource Not Found

### Request
```bash
TOKEN="your_jwt_token_here"

curl -X GET http://localhost:8080/api/users/9999 \
  -H "Authorization: Bearer $TOKEN" | json_pp
```

### Response (404 Not Found)
```json
{
  "timestamp": "2024-02-14T12:36:30Z",
  "status": 404,
  "message": "User not found with id: 9999",
  "path": "uri=/api/users/9999"
}
```

---

## Testing with Postman

### 1. Create Environment Variables
```json
{
  "base_url": "http://localhost:8080/api",
  "volunteer_token": "",
  "organizer_token": ""
}
```

### 2. Collection Setup

**Register Volunteer** (Save response token)
- Method: POST
- URL: {{base_url}}/auth/register
- Body: (see example above)
- Tests: 
  ```javascript
  pm.environment.set("volunteer_token", pm.response.json().token);
  ```

**Register Organizer** (Save response token)
- Method: POST
- URL: {{base_url}}/auth/register
- Body: (see example above)
- Tests:
  ```javascript
  pm.environment.set("organizer_token", pm.response.json().token);
  ```

**Get Users** (Authorized)
- Method: GET
- URL: {{base_url}}/users
- Headers:
  - Authorization: Bearer {{volunteer_token}}

**Create User** (Organizer Only)
- Method: POST
- URL: {{base_url}}/users
- Headers:
  - Authorization: Bearer {{organizer_token}}
- Body: (see example above)

---

## Testing Steps

### Step 1: Start Application
```bash
mvn spring-boot:run
```

### Step 2: Register Accounts
- Register a volunteer account
- Register an organizer account
- Save both JWT tokens

### Step 3: Test Authorization
- Use volunteer token to:
  - ✅ GET /users
  - ✅ GET /users/{id}
  - ❌ POST /users (should fail)
  - ❌ PUT /users/{id} (should fail)
  - ❌ DELETE /users/{id} (should fail)

- Use organizer token to:
  - ✅ GET /users
  - ✅ POST /users
  - ✅ PUT /users/{id}
  - ✅ DELETE /users/{id}

### Step 4: Test Error Cases
- Invalid credentials
- Duplicate username
- Duplicate email
- Password mismatch
- Invalid token
- Missing token
- Resource not found

---

## Token Decoding

Decode JWT to verify claims:

```bash
# Extract and decode JWT (online at jwt.io or use jq)
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Split and decode header
echo $TOKEN | cut -d'.' -f1 | base64 -d | jq .

# Split and decode payload
echo $TOKEN | cut -d'.' -f2 | base64 -d | jq .

# Signature (base64url encoded)
echo $TOKEN | cut -d'.' -f3
```

### Example Decoded Payload
```json
{
  "sub": "alice_volunteer",
  "roles": "ROLE_VOLUNTEER",
  "iat": 1707892200,
  "exp": 1707978600
}
```

---

## Performance Testing

### Load Testing with Apache Bench
```bash
# Single request (warm up)
ab -n 1 -c 1 http://localhost:8080/api/users

# 100 requests, 10 concurrent
# (will fail without token - expected)
ab -n 100 -c 10 http://localhost:8080/api/users

# With Authorization header (requires ab with header support)
# Use alternative tools like wrk or apache jmeter
```

---

## Debugging

### Enable Debug Logging
Edit `application.yml`:
```yaml
logging:
  level:
    org.springframework.security: DEBUG
    com.volunteerhub: DEBUG
```

### Check Logs for Token Details
```bash
# Look for "Could not set user authentication" messages
tail -f logs/app.log | grep "security"
```

### Database Verification
```sql
-- Check created users
SELECT id, username, email, role, active FROM users;

-- Query specific user
SELECT * FROM users WHERE username = 'alice_volunteer';
```

---

## Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Missing/Invalid token | Add Authorization header with valid JWT |
| 403 Forbidden | Insufficient role | Use credentials with required role |
| 409 Conflict | Duplicate username/email | Use unique values or check DB |
| 400 Bad Request | Invalid input | Check field validation messages |
| 404 Not Found | Resource doesn't exist | Verify ID exists in database |
| 500 Internal Error | Server issue | Check logs, verify DB connection |

