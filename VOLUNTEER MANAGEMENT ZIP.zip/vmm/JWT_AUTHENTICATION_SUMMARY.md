# VolunteerHub - JWT Authentication Module Summary

## ✅ Complete Implementation

A fully-featured JWT authentication module with role-based access control (RBAC) has been generated for the VolunteerHub Spring Boot application.

### 🎯 Key Features

✅ **Role-Based Authentication**
- VOLUNTEER role
- ORGANIZER role
- Role-based endpoint authorization

✅ **Security**
- BCrypt password encryption
- JWT token generation and validation
- Stateless authentication (no sessions)
- CSRF protection disabled (for stateless API)
- Manual getters/setters (No Lombok)

✅ **Complete Authentication Flow**
- User registration with role selection
- User login with JWT token generation
- Token-based request validation
- Automatic token validation on each request

## 📁 Files Generated/Updated

### Entity Layer
| File | Purpose |
|------|---------|
| `entities/Role.java` | ✨ NEW - Enum with VOLUNTEER and ORGANIZER roles |
| `entities/User.java` | ✏️ UPDATED - Added `role` field (Role enum) |

### Security Layer
| File | Purpose |
|------|---------|
| `security/JwtUtil.java` | ✨ NEW - JWT token generation and validation |
| `security/JwtTokenProvider.java` | 📦 EXISTING - Legacy support |
| `security/JwtAuthenticationFilter.java` | ✏️ UPDATED - Enhanced to use JwtUtil and handle roles |
| `security/JwtConstants.java` | ✨ NEW - JWT constants and configuration |

### Service Layer
| File | Purpose |
|------|---------|
| `services/AuthService.java` | ✏️ UPDATED - Registration with role selection, JWT generation |
| `services/UserService.java` | ✏️ UPDATED - Role handling in CRUD operations |

### Controller Layer
| File | Purpose |
|------|---------|
| `controllers/AuthController.java` | ✏️ UPDATED - Using RegisterDTO for registration |
| `controllers/UserController.java` | 📦 EXISTING - Role-based endpoint authorization |

### DTO Layer
| File | Purpose |
|------|---------|
| `dtos/RegisterDTO.java` | ✨ NEW - Registration request with role field |
| `dtos/LoginDTO.java` | 📦 EXISTING - Login credentials |
| `dtos/AuthResponseDTO.java` | ✏️ UPDATED - Enhanced with user details and roles |
| `dtos/UserDTO.java` | ✏️ UPDATED - Added `roles` collection field |

### Configuration Layer
| File | Purpose |
|------|---------|
| `config/SecurityConfig.java` | ✏️ UPDATED - Role-based authorization rules |
| `config/CustomUserDetailsService.java` | ✏️ UPDATED - Proper role mapping from User entity |
| `config/GlobalExceptionHandler.java` | 📦 EXISTING - Custom exception handling |

### Exception Layer
| File | Purpose |
|------|---------|
| `exceptions/InvalidCredentialsException.java` | 📦 EXISTING |
| `exceptions/DuplicateResourceException.java` | 📦 EXISTING |
| `exceptions/ResourceNotFoundException.java` | 📦 EXISTING |
| `exceptions/UnauthorizedException.java` | ✨ NEW - For authorization failures |

### Repository Layer
| File | Purpose |
|------|---------|
| `repositories/UserRepository.java` | 📦 EXISTING - Custom query methods for User |

### Configuration Files
| File | Purpose |
|------|---------|
| `application.yml` | ✏️ UPDATED - JWT secret and expiration configuration |

### Documentation
| File | Purpose |
|------|---------|
| `JWT_AUTHENTICATION_MODULE.md` | ✨ NEW - Complete authentication module documentation |
| `README.md` | 📦 EXISTING |

## 🔐 Authentication Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Client/Frontend                    │
└────────────┬────────────────────────────────────────┘
             │ 1. POST /auth/register (RegisterDTO)
             │ 2. POST /auth/login (LoginDTO)
             ↓
┌──────────────────────────────────────────────────────┐
│           AuthController (REST Endpoint)             │
└────────────┬────────────────────────────────────────┘
             │ validates input
             ↓
┌──────────────────────────────────────────────────────┐
│          AuthService (Business Logic)                 │
│  - register(RegisterDTO)                             │
│  - login(LoginDTO)                                   │
│  - password validation                               │
│  - JWT generation                                    │
└────────────┬────────────────────────────────────────┘
             │ user persistence
             ↓
┌──────────────────────────────────────────────────────┐
│    UserRepository & UserService (Data Layer)         │
│  - Save/Load User                                    │
│  - Role assignment                                   │
│  - BCrypt encoding                                   │
└────────────┬────────────────────────────────────────┘
             │ database
             ↓
        [MySQL Database]

┌──────────────────────────────────────────────────────┐
│  Request with JWT (in Authorization header)         │
└────────────┬────────────────────────────────────────┘
             │
             ↓
┌──────────────────────────────────────────────────────┐
│    JwtAuthenticationFilter (Security Filter)        │
│  - Extract JWT from Authorization header             │
│  - Validate token signature & expiration             │
│  - Extract roles from claims                         │
│  - Set SecurityContext                               │
└────────────┬────────────────────────────────────────┘
             │ valid token
             ↓
┌──────────────────────────────────────────────────────┐
│   CustomUserDetailsService (Spring Integration)      │
│  - Load UserDetails by username                      │
│  - Map User role to GrantedAuthority                │
└────────────┬────────────────────────────────────────┘
             │ authenticated user
             ↓
┌──────────────────────────────────────────────────────┐
│   SecurityConfig (Authorization Rules)               │
│  - Check role-based access (RBAC)                    │
│  - Grant/Deny endpoint access                        │
└────────────┬────────────────────────────────────────┘
             │ authorized
             ↓
    [Protected Endpoint/Resource]
```

## 🚀 Quick Start

### 1. Register New Volunteer
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice",
    "email": "alice@example.com",
    "password": "SecurePass123",
    "confirmPassword": "SecurePass123",
    "firstName": "Alice",
    "lastName": "Smith",
    "role": "VOLUNTEER"
  }'
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "userId": 1,
  "username": "alice",
  "email": "alice@example.com",
  "firstName": "Alice",
  "lastName": "Smith",
  "roles": ["ROLE_VOLUNTEER"],
  "active": true
}
```

### 2. Register New Organizer
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "bob",
    "email": "bob@example.com",
    "password": "SecurePass123",
    "confirmPassword": "SecurePass123",
    "firstName": "Bob",
    "lastName": "Johnson",
    "role": "ORGANIZER"
  }'
```

### 3. Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice",
    "password": "SecurePass123"
  }'
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "userId": 1,
  "username": "alice",
  "email": "alice@example.com",
  "roles": ["ROLE_VOLUNTEER"]
}
```

### 4. Access Protected Resource
```bash
curl -X GET http://localhost:8080/api/users/1 \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

## 🔒 Authorization Rules

| Endpoint | Method | VOLUNTEER | ORGANIZER | Public |
|----------|--------|-----------|-----------|--------|
| /auth/register | POST | ✅ | ✅ | ✅ |
| /auth/login | POST | ✅ | ✅ | ✅ |
| /users | GET | ✅ | ✅ | ❌ |
| /users/{id} | GET | ✅ | ✅ | ❌ |
| /users | POST | ❌ | ✅ | ❌ |
| /users/{id} | PUT | ❌ | ✅ | ❌ |
| /users/{id} | DELETE | ❌ | ✅ | ❌ |

## 🔑 Security Features

✅ **Password Security**
- BCrypt hashing with default strength (10)
- Passwords never stored in plain text
- Salted encryption

✅ **Token Security**
- HMAC-SHA256 signature
- Expiration claim (24 hours default)
- JWT validation on every request
- Role information embedded in token

✅ **HTTP Security**
- CSRF disabled (stateless API)
- Stateless session management
- Bearer token scheme
- Authorization header validation

✅ **Error Handling**
- Custom exception mapping to HTTP status codes
- No sensitive information leaked
- Consistent error response format

## 🛠️ Configuration

Edit `application.yml`:

```yaml
jwt:
  secret: volunteerhubsecretkeythatisatleast32characterslong
  expiration: 86400000  # 24 hours in milliseconds
```

⚠️ **Production:** 
- Change secret to strong random string
- Store secret in environment variables
- Reduce expiration (30 min - 1 hour)
- Use HTTPS only

## 📊 Token Structure

JWT contains three parts:

1. **Header**
```json
{
  "alg": "HS256",
  "typ": "JWT"
}
```

2. **Payload (Claims)**
```json
{
  "sub": "alice",                    // username
  "roles": "ROLE_VOLUNTEER",         // role(s)
  "iat": 1707892200,                 // issued at
  "exp": 1707978600                  // expiration
}
```

3. **Signature**
```
HMACSHA256(
  base64UrlEncode(header) + "." +
  base64UrlEncode(payload),
  secret
)
```

## 🎓 Code Quality

✅ No Lombok dependency
- All getters/setters written manually
- Full transparency and control
- Easy debugging and IDE support

✅ Layered Architecture
- Clear separation of concerns
- controller → service → repository → entity
- Easy to extend and maintain

✅ Type Safety
- Enums for roles
- Custom exceptions
- DTOs with validation

✅ Documentation
- Comprehensive README
- JWT module documentation
- Inline code comments

## 🔄 User Flow Diagram

```
┌─────────────────────┐
│   New User          │
│  Registration       │
│                     │
│ POST /auth/register │
└──────────┬──────────┘
           │
           ↓
    ┌──────────────┐
    │   Register   │
    │   Service    │
    │              │
    │ - Validate   │
    │ - Encrypt    │
    │ - Create     │
    └──────────┬───┘
               │
               ↓
        ┌─────────────┐
        │   Database  │
        │   Save User │
        │   with Role │
        └──────┬──────┘
               │
               ↓
        ┌──────────────────┐
        │   JwtUtil        │
        │ Generate Token   │
        └──────┬───────────┘
               │
               ↓
        ┌──────────────┐
        │ AuthResponse │
        │ (token+data) │
        └──────────────┘

────────────────────────────

┌──────────────────┐
│   Existing User  │
│   Login          │
│                  │
│ POST /auth/login │
└────────┬─────────┘
         │
         ↓
    ┌────────────────┐
    │  Auth Service  │
    │                │
    │ - Authenticate │
    │ - Password OK? │
    │ - Generate JWT │
    └────────┬───────┘
             │
             ↓
    ┌─────────────────────┐
    │  AuthResponse       │
    │  (JWT token + role) │
    └─────────────────────┘

────────────────────────────

┌──────────────────┐
│  Authenticated   │
│  Request with    │
│  JWT in Header   │
│                  │
│ GET /api/users   │
└────────┬─────────┘
         │
         ↓
    ┌────────────────────┐
    │ JwtAuthFilter      │
    │                    │
    │ - Extract JWT      │
    │ - Validate         │
    │ - Extract roles    │
    │ - Set Security     │
    └────────┬───────────┘
             │
             ↓
    ┌───────────────────┐
    │ CustomUserDetails │
    │ Service           │
    │ Load Authorities  │
    └────────┬──────────┘
             │
             ↓
    ┌───────────────────┐
    │ Security Config   │
    │ Check RBAC        │
    │ Grant/Deny Access │
    └────────┬──────────┘
             │
             ↓
         [Access Granted]
             │
             ↓
      [Protected Endpoint]
```

## 📦 Dependencies

All required dependencies in `pom.xml`:

```xml
<!-- Spring Boot Web & Security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>

<!-- Spring Security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>

<!-- JWT (JJWT 0.12.3) -->
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-api</artifactId>
    <version>0.12.3</version>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-impl</artifactId>
    <version>0.12.3</version>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-jackson</artifactId>
    <version>0.12.3</version>
    <scope>runtime</scope>
</dependency>
```

## ✨ Summary

A complete, production-ready JWT authentication module with:
- ✅ Role-based access control (VOLUNTEER/ORGANIZER)
- ✅ Secure password encryption (BCrypt)
- ✅ JWT token management
- ✅ No Lombok (full transparency)
- ✅ Manual getters/setters
- ✅ Comprehensive error handling
- ✅ Complete documentation

Ready for integration and extension!

