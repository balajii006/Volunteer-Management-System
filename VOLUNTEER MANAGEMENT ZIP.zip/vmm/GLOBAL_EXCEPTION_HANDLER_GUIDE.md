# GlobalExceptionHandler Implementation Summary

## Overview

The **GlobalExceptionHandler** is a centralized error handling mechanism for the VolunteerHub REST API. It provides consistent, standardized responses across all endpoints by automatically converting exceptions to the standard `ApiResponse` format.

## Components

### 1. ApiResponse DTO
**File:** `ApiResponse.java`  
**Location:** `com.volunteerhub.dtos`

A generic wrapper class for all API responses:

```java
public class ApiResponse<T> {
    private String status;      // SUCCESS, ERROR, VALIDATION_ERROR, etc.
    private String message;     // Human-readable message
    private T data;            // Response payload
    private Long timestamp;    // Response timestamp in milliseconds
}
```

**Factory Methods:**
- `ApiResponse.success(message)` - 200 OK
- `ApiResponse.success(message, data)` - 200 OK with data
- `ApiResponse.error(message)` - 500 INTERNAL_SERVER_ERROR
- `ApiResponse.validationError(message, errors)` - 400 BAD_REQUEST
- `ApiResponse.unauthorized(message)` - 401 UNAUTHORIZED
- `ApiResponse.forbidden(message)` - 403 FORBIDDEN
- `ApiResponse.notFound(message)` - 404 NOT_FOUND
- `ApiResponse.conflict(message)` - 409 CONFLICT

### 2. GlobalExceptionHandler
**File:** `GlobalExceptionHandler.java`  
**Location:** `com.volunteerhub.config`

Handles all exceptions and converts them to `ApiResponse` format with appropriate HTTP status codes.

**Exception Handlers:**

| Exception | HTTP Status | Status Type | Message |
|-----------|-----------|------------|---------|
| ResourceNotFoundException | 404 | NOT_FOUND | "Event not found..." |
| InvalidCredentialsException | 401 | UNAUTHORIZED | "Invalid credentials..." |
| UnauthorizedException | 403 | FORBIDDEN | "Not authorized..." |
| DuplicateResourceException | 409 | CONFLICT | "Already exists..." |
| BadCredentialsException | 401 | UNAUTHORIZED | "Invalid username or password" |
| MethodArgumentNotValidException | 400 | VALIDATION_ERROR | Field-level errors |
| MethodArgumentTypeMismatchException | 400 | ERROR | "Parameter 'x' could not be converted..." |
| NoHandlerFoundException | 404 | NOT_FOUND | "Resource not found: {method} {path}" |
| IllegalArgumentException | 400 | ERROR | Custom message |
| Generic Exception | 500 | ERROR | "An unexpected error occurred..." |

## Response Status Codes

### HTTP Status Codes Used

```
200 OK                  - Successful GET, PUT
201 Created            - Successful POST
204 No Content         - Successful DELETE
400 Bad Request        - Validation errors, Invalid arguments
401 Unauthorized       - Invalid credentials
403 Forbidden          - Lacks permission
404 Not Found          - Resource not found
409 Conflict           - Duplicate resource
500 Internal Server Error - Unexpected errors
```

## How It Works

### 1. Exception Occurs
```java
// In a controller or service
if (!event.getOrganizer().getId().equals(userId)) {
    throw new UnauthorizedException("You are not authorized...");
}
```

### 2. GlobalExceptionHandler Catches It
```java
@ExceptionHandler(UnauthorizedException.class)
public ResponseEntity<ApiResponse<Object>> handleUnauthorizedException(
        UnauthorizedException ex, WebRequest request) {
    ApiResponse<Object> response = ApiResponse.forbidden(ex.getMessage());
    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
}
```

### 3. Returns Standard Format
```json
{
  "status": "FORBIDDEN",
  "message": "You are not authorized to update this event...",
  "data": null,
  "timestamp": 1707858000000
}
```

## Exception Hierarchy

```
Throwable
├── Exception
│   ├── RuntimeException (Custom)
│   │   ├── ResourceNotFoundException
│   │   ├── InvalidCredentialsException
│   │   ├── UnauthorizedException
│   │   └── DuplicateResourceException
│   ├── RuntimeException (Spring)
│   │   └── BadCredentialsException
│   └── Other Spring Exceptions
│       ├── MethodArgumentNotValidException
│       ├── MethodArgumentTypeMismatchException
│       └── NoHandlerFoundException
```

## Usage Examples

### Register a New User - Success
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "email": "john@example.com",
    "password": "SecurePass123",
    "firstName": "John",
    "lastName": "Doe",
    "role": "VOLUNTEER"
  }'
```

**Response (201):**
```json
{
  "status": "SUCCESS",
  "message": "User registered successfully",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "userId": 1,
    "username": "johndoe"
  },
  "timestamp": 1707858000000
}
```

### Register with Validation Errors
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "jo",
    "email": "invalid",
    "password": "short"
  }'
```

**Response (400):**
```json
{
  "status": "VALIDATION_ERROR",
  "message": "Validation failed",
  "data": {
    "username": "Username must be between 5 and 50 characters",
    "email": "Email should be valid",
    "password": "Password must be at least 8 characters",
    "firstName": "First name is required",
    "lastName": "Last name is required"
  },
  "timestamp": 1707858000000
}
```

### Create Event as Organizer
```bash
curl -X POST http://localhost:8080/api/events \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Beach Cleanup",
    "location": "Santa Monica Beach",
    "eventDate": "2026-03-15T10:00:00",
    "startTime": "2026-03-15T10:00:00",
    "endTime": "2026-03-15T14:00:00",
    "maxVolunteers": 50
  }'
```

**Response (201):**
```json
{
  "status": "SUCCESS",
  "message": "Event created successfully",
  "data": {
    "id": 1,
    "title": "Beach Cleanup",
    "status": "SCHEDULED",
    "maxVolunteers": 50
  },
  "timestamp": 1707858000000
}
```

### Unauthorized Access - Not an Organizer
```bash
curl -X PUT http://localhost:8080/api/events/1 \
  -H "Authorization: Bearer <volunteer_token>" \
  -H "Content-Type: application/json" \
  -d '{"title": "Updated"}'
```

**Response (403):**
```json
{
  "status": "FORBIDDEN",
  "message": "You are not authorized to update this event. Only the organizer can modify events.",
  "data": null,
  "timestamp": 1707858000000
}
```

### Duplicate Resource - Already Joined
```bash
curl -X POST http://localhost:8080/api/events/1/join \
  -H "Authorization: Bearer <token>"
```

**Response (409):**
```json
{
  "status": "CONFLICT",
  "message": "Volunteer has already joined this event.",
  "data": null,
  "timestamp": 1707858000000
}
```

### Resource Not Found
```bash
curl -X GET http://localhost:8080/api/events/999 \
  -H "Authorization: Bearer <token>"
```

**Response (404):**
```json
{
  "status": "NOT_FOUND",
  "message": "Event not found with ID: 999",
  "data": null,
  "timestamp": 1707858000000
}
```

## Validation Error Handling

### Custom Annotations Used
- `@NotBlank` - String must not be null/empty
- `@NotNull` - Field must not be null
- `@Email` - Must be valid email format
- `@Min` / `@Max` - Numeric range validation
- `@PositiveOrZero` - Must be positive or zero
- `@Size` - String length validation

### Example DTO with Validation
```java
public class RegisterDTO {
    @NotBlank(message = "Username is required")
    @Size(min = 5, max = 50)
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;

    @NotNull(message = "First name is required")
    private String firstName;
}
```

### Validation Error Response
All validation errors are automatically collected and returned with status: VALIDATION_ERROR

```json
{
  "status": "VALIDATION_ERROR",
  "message": "Validation failed",
  "data": {
    "username": "Username must be between 5 and 50 characters",
    "email": "Email should be valid",
    "password": "Password must be at least 8 characters",
    "firstName": "First name is required"
  },
  "timestamp": 1707858000000
}
```

## Best Practices

### 1. Always Use Custom Exceptions
```java
// Good
if (event == null) {
    throw new ResourceNotFoundException("Event not found with ID: " + eventId);
}

// Avoid
if (event == null) {
    return ResponseEntity.notFound().build();
}
```

### 2. Provide Descriptive Messages
```java
// Good
throw new ResourceNotFoundException("Event not found with ID: " + eventId);

// Avoid
throw new ResourceNotFoundException("Not found");
```

### 3. Use Validation Annotations in DTOs
```java
// Good
public class CreateEventDTO {
    @NotBlank(message = "Event title is required")
    private String title;
}

// Avoid
public class CreateEventDTO {
    private String title;
}
```

### 4. Let GlobalExceptionHandler Handle Conversions
```java
// Good - Exception is caught by GlobalExceptionHandler
throw new ResourceNotFoundException("Event not found");

// Avoid - Manual response mapping
if (event == null) {
    return ResponseEntity.status(HttpStatus.NOT_FOUND)
        .body(new ErrorResponse(...));
}
```

## Configuration

### Spring Boot application.yml
```yaml
server:
  error:
    include-message: always
    include-binding-errors: always
    include-stacktrace: never
    include-exception: false
```

### Enable 404 Handling
```yaml
spring:
  mvc:
    throw-exception-if-no-handler-found: true
  web:
    resources:
      add-mappings: false
```

## Testing Exception Handling

### JUnit Test Example
```java
@Test
void testUnauthorizedAccess() {
    // Assert that UnauthorizedException is thrown
    assertThrows(UnauthorizedException.class, () -> {
        eventService.updateEvent(eventId, updateDTO, wrongUserId);
    });
}

@Test
void testDuplicateJoin() {
    // First join succeeds
    participationService.joinEvent(eventId, volunteerId);
    
    // Second join throws DuplicateResourceException
    assertThrows(DuplicateResourceException.class, () -> {
        participationService.joinEvent(eventId, volunteerId);
    });
}
```

## Architecture Diagram

```
Request
  ↓
Controller
  ↓
Service (throws exception)
  ↓
GlobalExceptionHandler (catches)
  ↓
ApiResponse (wraps)
  ↓
HTTP Response with status code
  ↓
Client
```

## Summary

✅ **Consistent Response Format** - All APIs return standard ApiResponse  
✅ **Proper HTTP Status Codes** - Correct codes for each error type  
✅ **Validation Error Details** - Field-level error information  
✅ **Centralized Handling** - Single place for all error logic  
✅ **Type-Safe Responses** - Generic ApiResponse<T> for type safety  
✅ **Timestamp Tracking** - All responses include generation timestamp  
✅ **Extensible Design** - Easy to add new exception handlers
